<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\Storage;
use DB;
use View;
use Session;
use Auth;
use File;
use App\ApplicationRequest;
use App\ConactUs;


class ApplicationRequestController extends Controller
{
    //

    public function new_application(Request $req) // email updation
    {


        ApplicationRequest::create($req->all());

            $lastid = DB::getPdo()->lastInsertId();

            

            if($lastid != '')
            {
                return redirect()->back()->withErrors(['Request Submitted Succesfully!!']);
            }
            else
            {
                return redirect()->back()->withErrors(['Sorry !! SOmething went wrong!. Request cannot be submit now.']);
            }
        }



        public function post_contact_message(Request $req) // email updation
        {
    
    
            ConactUs::create($req->all());
    
                $lastid = DB::getPdo()->lastInsertId();
    
                
    
                if($lastid != '')
                {
                    return redirect()->back()->withErrors(['Message Sent Succesfully!!']);
                }
                else
                {
                    return redirect()->back()->withErrors(['Sorry !! SOmething went wrong!. Message cannot be send now.']);
                }
            }

}
