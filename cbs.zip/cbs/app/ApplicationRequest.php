<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ApplicationRequest extends Model
{
    //

    protected $table = 'cbs_application_request';
    protected $fillable = [
        'name','phone','email',
        'req_type','status','message'
        
    ];
}
