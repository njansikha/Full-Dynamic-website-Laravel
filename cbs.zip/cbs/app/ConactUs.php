<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ConactUs extends Model
{
    //
    protected $table = 'cbs_contactus';
    protected $fillable = [
        'name','phone','email',
        'subject','status','message'
        
    ];
}
