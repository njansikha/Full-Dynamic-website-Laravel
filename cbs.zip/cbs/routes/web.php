<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});
Route::get('/about-us', function () {
    return view('about');
});
Route::get('/services', function () {
    return view('service');
});
Route::get('/testimonials', function () {
    return view('testimonials');
    
});
Route::get('/careers', function () {
    return view('career');
    
});
Route::get('/credit-cards', function () {
    return view('credit_cards');
});
Route::get('/home-loans', function () {
    return view('home_loans');
});
Route::get('/personal-loans', function () {
    return view('personal_loans');
});
Route::get('/gold-loans', function () {
    return view('gold_loans');
});

Route::get('/property-loans', function () {
    return view('property_loans');
});
Route::get('/loan-transfer', function () {
    return view('loan_transfer');
});
Route::get('/wealth-management', function () {
    return view('wealth_management');
});
Route::get('/investment-management', function () {
    return view('investment_management');
});
Route::get('/contact', function () {
    return view('contact');
});

Route::get('/partners', function () {
    return view('partners');
});
Route::get('/testimonials', function () {
    return view('testimonials');
});


Route::post('/submit_application','ApplicationRequestController@new_application');
Route::post('/post-contact-message','ApplicationRequestController@post_contact_message');


