<!DOCTYPE html>
<html lang="en-US">
@include('includes.head')
   <style>
          table, th, td {
  border: 1px solid black;
  text-align:center;
  padding: auto;
}

      </style>
   <body>
   <?php $req_type="pl";
       ?>
       
      <!-- Header Area Start -->
      <header class="finves-header-area">
         <!-- Header Top Area Start -->
         @include('includes.headertop')
         <!-- Header Top Area End -->
          
         <!-- Logo Area Start -->
         @include('includes.navarea')
         <!-- Logo Area End -->
      </header>
      <!-- Header Area End -->
       
       
      <!-- Breadcrumb Area Start -->
      <section class="finves-breadcromb-area">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="breadcromb-box">
                     <h3>Personal Loans</h3>
                     <ul>
                        <li><i class="fa fa-home"></i></li>
                        <li><a href="{{ url('/') }}">Home</a></li>
                        <li><i class="fa fa-angle-right"></i></li>
                        <li>Loans</li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Breadcrumb Area End -->
       
       
      <!-- Service Details Area Start -->
      <section class="finves-service-details section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-4">
                  <div class="sidebar-left">
                 
                  </div>
               </div>
               <div class="col-lg-8">

               <div class="col-sm-12">
                    @if(count($errors)>0)
                    @foreach($errors->all() as $error)
                  
                        <center> <font color="red">{{$error}} </font>  </center>
              
                    @endforeach
                    @endif
                </div>
                  <div class="service-details-right">
                     <h2>Personal Loans</h2>
                     <p>

                        A personal loan is the best option to get access to funds in case of an emergency. Once you 
fulfill the necessary Personal Eligibility Criteria, you can meet any expense like medical 
emergency, travel needs, education fees, etc. with this simple, unsecured loan. 
                     </p>
                     <ul class="list-service-details">
                        <li> Current lowest personal loan interest rates start from 10.25% p.a.
                        </li>
                        <li> Compare 100+ personal loan banks at Crest Banking Services and choose the best one.
                        </li>
                        <li> Check fees & charges of all top banks offering personal loans in India.
                        </li>
                        <li> Get flexible tenure of 36 to 84 months to repay the loan.
                        </li>
                        <li> Submit online loan application and get instant loan approva
                        </li>
                        
                    
                     </ul>
                     <div class="service-right-image">
                        <div class="row">
                           <div class="col-lg-6 col-sm-6">
                              <div class="single-right-img">
                                 <img src="assets/img/service-7.jpg" alt="service 1" />
                              </div>
                           </div>
                           <div class="col-lg-6 col-sm-6">
                              <div class="single-right-img">
                                 <img src="assets/img/service-6.jpg" alt="service 2" />
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                     <div class="col-lg-6 col-sm-6">
                     <div class="service-inn">
                        <h3>Features and Benifits
                        </h3>
                        <p style="text-align: justify;">

                          <ul class="list-service-details">
                           <li>Sense of accomplishment</li> 
                           <li>Tax benefits on interest and principal components</li> 
                           <li>Zero prepayment charges</li> 
                           <li>Home loan top up and balance transfer facility</li> 
                           <li>Long repayment tenure of up to 30 years</li> 
                           <li>High loan amount of up to 5 Crores (can be more in some cases)</li> 
                           
                           <li>Repayment holiday facility</li> 
                           <li>Loan available as term loan and overdraft</li> 
                           <li>Fixed, floating, and hybrid rates of interest available</li> 
                       
                        </ul>   </p>
                     </div>
                    </div>

                    <div class="col-lg-6 col-sm-6">
                        <div class="service-inn">
                           <h3>Interest Rates & Charges
                           </h3>
                           <p>
                            With personal loans, you have the option of both floating and fixed interest rates. Floating 
                            interest rates are linked to MCLR or Repo Rates depending upon the bank.
                            Here is a list of the Best Home Loan in India and the interest rates offered

                         </p>
                         <table >
                             <tr>
                                 <th>
                                     Bank
                                 </th>
                                 <th>
                                     Interest Rate
                                 </th>
                             </tr>
                             <tr>
                                 <td>State Bank of India</td>
                                 <td>6.70%
                                </td>
                             </tr>
                             <tr>
                                <td>State Bank of India</td>
                                <td>6.70%
                               </td>
                            </tr>
                            <tr>
                                <td>Kotak Mahindra bank</td>
                                <td>6.65%
                               </td>
                            </tr>
                            <tr>
                                <td>Citibank</td>
                                <td>6.75%

                               </td>
                            </tr>
                            
 
 
 
 
 
 
                            <tr>
                                <td>Union bank of India</td>
                                <td> 6.80%
                               </td>
                            </tr>

                            <tr>
                                <td>Bank of Baroda</td>
                                <td> 6.85%
                               </td>
                            </tr>
                            <tr>
                                <td>The Central bank of India</td>
                                <td> 6.85%
                               </td>
                            </tr>
                            <tr>
                                <td>Bank of India</td>
                                <td> 6.85%
                               </td>
                            </tr>
                            <tr>
                                <td>HDFC Ltd</td>
                                <td> 6.75%
                               </td>
                            </tr>
                            <tr>
                                <td>ICICI Bank</td>
                                <td> 6.90%
                               </td>
                            </tr>
                           
                         </table>
                    </div>
                   </div>


                    </div>

                     <!-- <div class="service_chart">
                        <h3>Strategy Develoment</h3>
                        <div id="morris_line_chart"></div>
                     </div> -->
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Service Details Area End -->
       
       
       
      @include('includes.footerarea')
   </body>
</html>

