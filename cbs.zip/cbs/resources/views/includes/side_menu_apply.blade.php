<div class="single-sidebar">
                        <div class="sidebar-appointment">
                           <h3>Make an Application</h3>
                           <form method="post" action="{{ url('/submit_application') }}" enctype="multipart/form-data"> 
                    {{ csrf_field() }} 
                              <p>
                                 <input type="text" placeholder="Name" name="name" />
                              </p>
                              <p>
                                 <input type="email" placeholder="E-mail" name="email" />
                              </p>
                              <p>
                                 <input type="text" placeholder="Contact Number" name="phone" />
                              </p>
                              <p>
                                 <textarea placeholder="Your Message" name="message"></textarea>
                              </p>
                              <input type="hidden" name="req_type" value="{{$req_type}}">
                              <input type="hidden" name="status" value="requested">
                              <p>
                                 <button type="submit">Send Request</button>
                              </p>
                           </form>
                        </div>
                     </div>