<div class="single-sidebar">
                        <ul class="service-menu">
                           <li class="active"><a href="{{ url('/loans') }}">LOANS</a></li>
                           <li ><a href="{{ url('/home-loans') }}">Home Loans</a></li>
                           <li><a href="{{ url('/personal-loans') }}">Personal Loans</a></li>
                           <li><a href="{{ url('/gold-loans') }}">Gold Loans</a></li>
                           <li><a href="{{ url('/property-loans') }}">Loan Aganist Property</a></li>
                           <li><a href="{{ url('/loan-transfer') }}">Loan Balance Transfer</a></li>
                           <li class="active"><a href="{{ url('/credit-cards') }}">CREDIT CARDS</a></li>
                           <li class="active"><a href="{{ url('/wealth-management') }}">WEALTH MANAGEMENT </a></li>
                           <li class="active"><a href="{{ url('/investment-management') }}">INVETSMENT MANAGEMENT </a></li>
                        </ul>
                     </div>