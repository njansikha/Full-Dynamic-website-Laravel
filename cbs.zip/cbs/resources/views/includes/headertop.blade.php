<div class="finves-header-top-area">
            <div class="container">
               <div class="row">
                  <div class="col-lg-6 col-md-6">
                     <div class="header-top-left">

                     <?php

// ->value('logobig');
$email = DB::table('cbs_companyinfo')->where('id', '1')
    ->value('email');
    $insta = DB::table('cbs_companyinfo')->where('id', '1')
    ->value('insta');
    $fb = DB::table('cbs_companyinfo')->where('id', '1')
    ->value('fb');
    $twitter = DB::table('cbs_companyinfo')->where('id', '1')
    ->value('twitter');
    $linkedin = DB::table('cbs_companyinfo')->where('id', '1')
    ->value('linkedin');
// echo $logobig;

?>
                        <p><a href="mailto:{{$email}}" style="color: white;">
                        <i class="fa fa-envelope-o"></i> &nbsp;{{$email}}</a></p>
                     </div>
                  </div>
                  <div class="col-lg-6 col-md-6">
                     <div class="header-top-right">
                        <div class="header-top-auth">
                           <!-- <a href="#"><i class="fa fa-user"></i>login/Register</a> -->
                        </div>
                        <div class="header-top-social">
                           <ul>
                              <li><a href="{{$fb}}" target="_blank"><i class="fa fa-facebook"></i></a></li>
                              <li><a href="{{$twitter}}" target="_blank"><i class="fa fa-twitter"></i></a></li>
                              <li><a href="{{$insta}}" target="_blank"><i class="fa fa-instagram"></i></a></li>
                              <li><a href="{{$linkedin}}" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>