<?php

// ->value('logobig');
$companyinfo = DB::table('cbs_companyinfo')->where('id', '1')
    ->get();
// echo $logobig;

?>

@foreach($companyinfo as $newcompanyinfo)
@endforeach




<footer class="finves-footer-area">
         <div class="footer-top-area">
            <div class="container">
               <div class="row">
                  <div class="col-lg-5 col-sm-6">
                     <div class="single-footer">
                        <h3>About Us</h3>
                        <p>Crest Banking Services to simplify your borrowing journey.</p>
                        <ul class="footer-about">
                           <li><i class="fa fa-map-marker"></i> <span>Address </span>: Trivandrum
                           </li>
                           <li><i class="fa fa-phone"></i> <span>Phone </span>: +91-{{$newcompanyinfo->phonenumber}}</li>
                           <li><i class="fa fa-envelope-o"></i> <span>Email </span>: {{$newcompanyinfo->email}}</li>
                           <li><a href="{{$newcompanyinfo->fb}}"><i class="fa fa-facebook"></i></a> &nbsp;
                           <a href="{{$newcompanyinfo->twitter}}"><i class="fa fa-twitter"></i></a>&nbsp;
                           <a href="{{$newcompanyinfo->insta}}"><i class="fa fa-instagram"></i></a>&nbsp;
                           <a href="{{$newcompanyinfo->linkedin}}"><i class="fa fa-linkedin"></i></a>&nbsp;
                           <a href="#"><i class="fa fa-skype"></i></a></li>
                       
                        </ul>
                        
                       
                        
                     </div>
                     
                      
                     
                  </div>
                  <div class="col-lg-3 col-sm-6">
                     <div class="single-footer">
                        <h3>Usefull Links</h3>
                        <ul class="usefull_links">
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Home</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>About Us</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Latest news</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Case Studies</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Meet Team</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Consultation</a></li>
                        </ul>
                        <ul class="usefull_links">
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Financial</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Private Banking</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Commodities</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Stock Holders</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Mutual Fund</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Stock Trading</a></li>
                        </ul>
                     </div>
                  </div>
                  <!-- <div class="col-lg-3 col-sm-6">
                     <div class="single-footer">
                        <h3>Subscribe Us</h3>
                        <p>Sign up for our mailing list to get latest updates and offers.</p>
                        <div class="footer-subscribe">
                           <form>
                              <input type="email" placeholder="Email Address" />
                              <button type="submit">GO</button>
                           </form>
                        </div>
                      
                     </div>
                  </div> -->
                  <div class="col-lg-3 col-sm-6">
                     <div class="single-footer">
                        <h3>Opening Hours</h3>
                        <ul class="footer-hours">
                           <li>Mon – Tue<span>{{$newcompanyinfo->monday}}</span></li>
                           <li>Wed – Thur<span>{{$newcompanyinfo->wednesday}}</span></li>
                           <li>Friday<span>{{$newcompanyinfo->friday}}</span></li>
                           <li>Saturday<span>{{$newcompanyinfo->satarday}}</span></li>
                           <li>Sunday<span>{{$newcompanyinfo->sunday}}</span></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="copyright-area">
            <div class="container">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="copyright">
                        <p>Developed by  <a href="https://finklinzitservices.com/" target="_blank">FinkLinz IT Services</a> </p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>

       <!--Jquery js-->
       <script src="assets/js/jquery.min.js"></script>
      <!-- Popper JS -->
      <script src="assets/js/popper.min.js"></script>
      <!--Bootstrap js-->
      <script src="assets/js/bootstrap.min.js"></script>
      <!-- Raphael JS -->
      <script src="assets/js/raphael.min.js"></script>
      <!-- Morris JS -->
      <script src="assets/js/morris.min.js"></script>
      <!-- Custom Morris JS For Only Demo Purpose -->
      <script src="assets/js/custom_morris.js"></script>
      <!--Owl-Carousel js-->
      <script src="assets/js/owl.carousel.min.js"></script>
      <!--Slicknav js-->
      <script src="assets/js/jquery.slicknav.min.js"></script>
      <!--Isotop js-->
      <script src="assets/js/isotope.pkgd.min.js"></script>
      <script src="assets/js/custom-isotop.js"></script>
      <!--Magnific js-->
      <script src="assets/js/jquery.magnific-popup.min.js"></script>
      <!--Nice Select js-->
      <script src="assets/js/jquery.nice-select.min.js"></script>
      <!-- Counter JS -->
      <script src="assets/js/jquery.counterup.min.js"></script>
      <!-- Way Points JS -->
      <script src="assets/js/waypoints-min.js"></script>
      <!--Main js-->
      <script src="assets/js/main.js"></script>