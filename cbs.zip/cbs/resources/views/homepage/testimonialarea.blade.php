<section class="finves-trestimonial-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <div class="testimonial-box">
                     <div class="testimonial-sldier owl-carousel">
                        <div class="single-testimonial">
                           <div class="testimonial-image">
                              <img src="assets/img/testimonial-1.png" alt="testimonial 1" />
                           </div>
                           <div class="testimonial-text">
                              <div class="testimonial-meta">
                                 <h3>noah baldon</h3>
                                 <p>Manager, ABC Company</p>
                              </div>
                              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus soluta quod illum sunt quis, in voluptas minusoll itia reiciendis facere culpa deserunt odit excepturi rerum aut dolores hic dicta alias similique! Unde officiis conno sequuntur amet minima esse, laborum, eaque, obcaecati quis placeat</p>
                           </div>
                        </div>
                        <div class="single-testimonial">
                           <div class="testimonial-image">
                              <img src="assets/img/testimonial-2.jpg" alt="testimonial 1" />
                           </div>
                           <div class="testimonial-text">
                              <div class="testimonial-meta">
                                 <h3>Jill Miller</h3>
                                 <p>CEO, DEB Company</p>
                              </div>
                              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus soluta quod illum sunt quis, in voluptas minusoll itia reiciendis facere culpa deserunt odit excepturi rerum aut dolores hic dicta alias similique! Unde officiis conno sequuntur amet minima esse, laborum, eaque, obcaecati quis placeat</p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>