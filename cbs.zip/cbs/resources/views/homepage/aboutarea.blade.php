<section class="finves-about-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-5">
                  <div class="about-page-left">
                     <img src="assets/img/about.jpg" alt="about">
                     <a class="popup-youtube" href="https://www.youtube.com/watch?v=k-R6AFn9-ek">
                     <i class="fa fa-play"></i>Watch Now
                     </a>
                  </div>
               </div>
               <div class="col-lg-7">
                  <div class="about-right">
                     <h3>About Crest</h3>
                     <h2>We are here to manage your finance with experience</h2>
                     <p><b>CBS </b>offers wide range of Financial 
                        Loans and other retail credit products that 
                        are designed to address an array of financing
                         needs with quick turnaround time.
                       <b><i>Our product pack
                        contains Personal Loans, 
                        Loan Against Property, Housing Loans,
                         Credit Cards and Debit Cards. </i> </b>
                        </p>
                     <div class="about-list clearfix">
                        <ul>
                           <li>
                              <div class="single-about-list">
                                 <div class="about-list-left">
                                    <i class="fa fa-check"></i>
                                 </div>
                                 <div class="about-list-right">
                                    <h4>Fast Approval</h4>
                                    <p>Emergency Loan with favorable repayment terms.</p>
                                 </div>
                              </div>
                           </li>
                           <li>
                              <div class="single-about-list">
                                 <div class="about-list-left">
                                    <i class="fa fa-check"></i>
                                 </div>
                                 <div class="about-list-right">
                                    <h4>Refinancing</h4>
                                    <p>Refinancing for 
                                       home,car,student loans etc.</p>
                                 </div>
                              </div>
                           </li>
                           <li>
                              <div class="single-about-list">
                                 <div class="about-list-left">
                                    <i class="fa fa-check"></i>
                                 </div>
                                 <div class="about-list-right">
                                    <h4>Free Documention</h4>
                                    <p>Free documenttaion support for customers.</p>
                                 </div>
                              </div>
                           </li>
                           <li>
                              <div class="single-about-list">
                                 <div class="about-list-left">
                                    <i class="fa fa-check"></i>
                                 </div>
                                 <div class="about-list-right">
                                    <h4>24/7 Support</h4>
                                    <p>Keep it with you for 24x7.</p>
                                 </div>
                              </div>
                           </li>
                        </ul>
                     </div>
                     <div class="call-us">
                        <div class="call-left">
                           <a href="#" class="finves-btn">More About Us <i class="fa fa-angle-double-right"></i></a>
                        </div>

                        <?php

// ->value('logobig');
$phonenumber2 = DB::table('cbs_companyinfo')->where('id', '1')
    ->value('phonenumber');
// echo $logobig;

?>
                        <div class="call-right">
                           <p>Call Us at <span><a href="tel:+91 {{$phonenumber2}}">+91{{$phonenumber2}}</a></span></p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>