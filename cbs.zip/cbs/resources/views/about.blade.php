<!DOCTYPE html>
<html lang="en-US">
@include('includes.head')
   <body>
       
       
      <!-- Header Area Start -->
      <header class="finves-header-area">
         <!-- Header Top Area Start -->
         @include('includes.headertop')
         <!-- Header Top Area End -->
          
         <!-- Logo Area Start -->
         @include('includes.navarea')
         <!-- Logo Area End -->
      </header>
      <!-- Header Area End -->
       
       
      <!-- Breadcrumb Area Start -->
      <section class="finves-breadcromb-area">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="breadcromb-box">
                     <h3>About Us</h3>
                     <ul>
                        <li><i class="fa fa-home"></i></li>
                        <li><a href="{{ url('/') }}">Home</a></li>
                        <li><i class="fa fa-angle-right"></i></li>
                        <li>About Us</li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Breadcrumb Area End -->
       
 
      <!-- About Area Start -->
      <!-- <section class="finves-about-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-5">
                  <div class="about-page-left">
                     <img src="assets/img/about.jpg" alt="about">
                     <a class="popup-youtube" href="https://www.youtube.com/watch?v=k-R6AFn9-ek">
                     <i class="fa fa-play"></i>Watch Now
                     </a>
                  </div>
               </div>
               <div class="col-lg-7">
                  <div class="about-right">
                     <h3>About Crest</h3>
                     <h2>We are here to manage your finance with experience</h2>
                     <p style="text-align:justify"><b>Crest Banking Services </b>offers wide range of Financial 
                        Loans and other retail credit products that 
                        are designed to address an array of financing
                         needs with quick turnaround time.
                         <br>
                       Our product pack
                        contains<b> Personal Loans, 
                        Loan Against Property, Housing Loans,
                         Credit Cards and Debit Cards</b>.
                        Crest Banking Services is India's largest phygital financial services marketplace facilitating 
                        real time application and solutions for your financial problems.</b></p>
                        <div class="about-list clearfix">
                           <ul>
                              <li>
                                 <div class="single-about-list">
                                    <div class="about-list-left">
                                       <i class="fa fa-check"></i>
                                    </div>
                                    <div class="about-list-right">
                                       <h4>Fast Approval</h4>
                                       <p>Emergency Loan with favorable repayment terms.</p>
                                    </div>
                                 </div>
                              </li>
                              <li>
                                 <div class="single-about-list">
                                    <div class="about-list-left">
                                       <i class="fa fa-check"></i>
                                    </div>
                                    <div class="about-list-right">
                                       <h4>Refinancing</h4>
                                       <p>Refinancing for 
                                          home,car,student loans etc.</p>
                                    </div>
                                 </div>
                              </li>
                              <li>
                                 <div class="single-about-list">
                                    <div class="about-list-left">
                                       <i class="fa fa-check"></i>
                                    </div>
                                    <div class="about-list-right">
                                       <h4>Free Documention</h4>
                                       <p>Free documenttaion support for customers.</p>
                                    </div>
                                 </div>
                              </li>
                              <li>
                                 <div class="single-about-list">
                                    <div class="about-list-left">
                                       <i class="fa fa-check"></i>
                                    </div>
                                    <div class="about-list-right">
                                       <h4>24/7 Support</h4>
                                       <p>Keep it with you for 24x7.</p>
                                    </div>
                                 </div>
                              </li>
                           </ul>
                        </div>
                     <div class="call-us">
                        <div class="call-left">
                           <a href="#" class="finves-btn">More About Us <i class="fa fa-angle-double-right"></i></a>
                        </div>
                        <div class="call-right">
                           <p>Call Us at <span></span></p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section> -->
      @include('homepage.aboutarea')
      <!-- About Area End -->
       
       
      <!-- Counter Area Start -->
      <section class="finves-counter-area">
         <div class="container">
            <div class="row">
               <div class="col-lg-3">
                  <div class="single-counter-box">
                     <div class="counter-icon">
                        <i class="fa fa-lightbulb-o"></i>
                     </div>
                     <div class="counter-text">
                        <h3><span class="counter">500</span></h3>
                        <p>Credit Cards</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-3">
                  <div class="single-counter-box">
                     <div class="counter-icon">
                        <i class="fa fa-globe"></i>
                     </div>
                     <div class="counter-text">
                        <h3><span class="counter">100</span></h3>
                        <p>Home Loans</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-3">
                  <div class="single-counter-box">
                     <div class="counter-icon">
                        <i class="fa fa-users"></i>
                     </div>
                     <div class="counter-text">
                        <h3><span class="counter">547</span></h3>
                        <p>Insurance</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-3">
                  <div class="single-counter-box">
                     <div class="counter-icon">
                        <i class="fa fa-thumbs-up"></i>
                     </div>
                     <div class="counter-text">
                        <h3><span class="counter">273</span></h3>
                        <p>Personal Loans</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Counter Area End -->
      <?php

// ->value('logobig');
$vision = DB::table('cbs_companyinfo')->where('id', '1')
    ->value('vision');
    $mission = DB::table('cbs_companyinfo')->where('id', '1')
    ->value('mission');
    $goals = DB::table('cbs_companyinfo')->where('id', '1')
    ->value('goals');
// echo $logobig;

?>
       
      <!-- Mission Area Start -->
      <section class="finves-mission-area section_70">
         <div class="container">
            <div class="row ">
               <div class="col-lg-6">
                  <div class="mission-area-left">
                     <div class="single-mission mission-box-one">
                        <h3>What we do?</h3>
                        <p> {{$vision}} </p>
                     </div>
                     <div class="single-mission mission-box-two">
                        <h3>Our mission</h3>
                        <p> {{$mission}}</p>
                     </div>
                     <div class="single-mission mission-box-three">
                        <h3>Our goal</h3>
                        <p>{{$goals}} </p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6">
                  <div class="mission-area-right">
                     <img src="assets/img/mission.jpg" alt="mission image" />
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Mission Area End -->
       
       
      <!-- Testimonial Area Start -->
      <!-- <section class="finves-trestimonial-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <div class="testimonial-box">
                     <div class="testimonial-sldier owl-carousel">
                        <div class="single-testimonial">
                           <div class="testimonial-image">
                              <img src="assets/img/testimonial-1.png" alt="testimonial 1" />
                           </div>
                           <div class="testimonial-text">
                              <div class="testimonial-meta">
                                 <h3>noah baldon</h3>
                                 <p>Manager, ABC Company</p>
                              </div>
                              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus soluta quod illum sunt quis, in voluptas minusoll itia reiciendis facere culpa deserunt odit excepturi rerum aut dolores hic dicta alias similique! Unde officiis conno sequuntur amet minima esse, laborum, eaque, obcaecati quis placeat</p>
                           </div>
                        </div>
                        <div class="single-testimonial">
                           <div class="testimonial-image">
                              <img src="assets/img/testimonial-2.jpg" alt="testimonial 1" />
                           </div>
                           <div class="testimonial-text">
                              <div class="testimonial-meta">
                                 <h3>Jill Miller</h3>
                                 <p>CEO, DEB Company</p>
                              </div>
                              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus soluta quod illum sunt quis, in voluptas minusoll itia reiciendis facere culpa deserunt odit excepturi rerum aut dolores hic dicta alias similique! Unde officiis conno sequuntur amet minima esse, laborum, eaque, obcaecati quis placeat</p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section> -->
      <!-- Testimonial Area End -->
       
       
    
       
       
      <!-- Footer Area Start -->
      @include('includes.footerarea')
      
      <!-- Footer Area End -->
       
       
 
   </body>
</html>

