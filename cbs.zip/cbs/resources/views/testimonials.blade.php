<!DOCTYPE html>
<html lang="en-US">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="description" content="Finves | Consulting Business, Finance HTML5 Template">
      <meta name="keyword" content="business, finance, investment, consulting">
      <meta name="author" content="Evrothemes">
      <!-- Title -->
      <title>Crest Banking Services</title>
      <!-- Favicon -->
      <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon/favicon-32x32.png">
      <!--Bootstrap css-->
      <link rel="stylesheet" href="assets/css/bootstrap.css">
      <!--Font Awesome css-->
      <link rel="stylesheet" href="assets/css/font-awesome.min.css">
      <!--Magnific css-->
      <link rel="stylesheet" href="assets/css/magnific-popup.css">
      <!--Owl-Carousel css-->
      <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
      <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
      <!--Animate css-->
      <link rel="stylesheet" href="assets/css/animate.min.css">
      <!--Nice Select css-->
      <link rel="stylesheet" href="assets/css/nice-select.css">
      <!--Slicknav css-->
      <link rel="stylesheet" href="assets/css/slicknav.min.css">
      <!--Site Main Style css-->
      <link rel="stylesheet" href="assets/css/style.css">
      <!--Responsive css-->
      <link rel="stylesheet" href="assets/css/responsive.css">
   </head>
   <body>
       
       
      <!-- Header Area Start -->
      <header class="finves-header-area">
         <!-- Header Top Area Start -->
         @include('includes.headertop')
         <!-- Header Top Area End -->
          
         <!-- Logo Area Start -->
         @include('includes.navarea')
         <!-- Logo Area End -->
      </header>

      <section class="finves-trestimonial-area section_70">
        <div class="container">
           <div class="row">
              <div class="col-lg-12">
                 <div class="testimonial-box">
                    <div class="testimonial-sldier owl-carousel">
                       <div class="single-testimonial">
                          <div class="testimonial-image">
                             <img src="assets/img/testimonial-1.png" alt="testimonial 1" />
                          </div>
                          <div class="testimonial-text">
                             <div class="testimonial-meta">
                                <h3>noah baldon</h3>
                                <p>Manager, ABC Company</p>
                             </div>
                             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus soluta quod illum sunt quis, in voluptas minusoll itia reiciendis facere culpa deserunt odit excepturi rerum aut dolores hic dicta alias similique! Unde officiis conno sequuntur amet minima esse, laborum, eaque, obcaecati quis placeat</p>
                          </div>
                       </div>
                       <div class="single-testimonial">
                          <div class="testimonial-image">
                             <img src="assets/img/testimonial-2.jpg" alt="testimonial 1" />
                          </div>
                          <div class="testimonial-text">
                             <div class="testimonial-meta">
                                <h3>Jill Miller</h3>
                                <p>CEO, DEB Company</p>
                             </div>
                             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus soluta quod illum sunt quis, in voluptas minusoll itia reiciendis facere culpa deserunt odit excepturi rerum aut dolores hic dicta alias similique! Unde officiis conno sequuntur amet minima esse, laborum, eaque, obcaecati quis placeat</p>
                          </div>
                       </div>
                    </div>
                 </div>
              </div>
           </div>
        </div>
     </section>

<!-- Investment Area Start -->
<section class="finves-investment-area section_70">
    <div class="container">
       <div class="row">
          <!-- <div class="col-lg-6">
             <div class="investment-left">
                <h2>EMI CALCULATOR</h2>
                <form>
                   <div class="row">
                      <div class="col-lg-6">
                         <p>
                            <label>Your Target ($)</label>
                            <input type="text" placeholder="1000000" />
                         </p>
                      </div>
                      <div class="col-lg-6">
                         <p>
                            <label>Duration (years)</label>
                            <input type="text" placeholder="7 years" />
                         </p>
                      </div>
                   </div>
                   <div class="row">
                      <div class="col-lg-6">
                         <p>
                            <label>Starting Principal ($)</label>
                            <input type="text" placeholder="5000" />
                         </p>
                      </div>
                      <div class="col-lg-6">
                         <p>
                            <label>Average Return (%)</label>
                            <input type="text" placeholder="5" />
                         </p>
                      </div>
                   </div>
                   <div class="row">
                      <div class="col-lg-6">
                         <p>
                            <label>Time Schedule</label>
                            <select class="wide">
                               <option>End of Each Month</option>
                               <option>End of Each Year</option>
                            </select>
                         </p>
                      </div>
                      <div class="col-lg-6">
                         <p>
                            <button type="submit">Calculate</button>
                         </p>
                      </div>
                   </div>
                </form>
             </div>
          </div> -->
          <div class="col-lg-12">
             <div class="investment-right">
                <h2>Customers</h2>
                <div id="morris_line_chart"></div>
             </div>
          </div>
       </div>
    </div>
 </section>
 <!-- Investment Area End -->
 <section class="finves-contact-area section_70">
   <div class="container">
      <div class="row">
        
         <div class="col-lg-12">
            <div class="contact-form">
               <form>
                  <div class="row">
                     <div class="col-lg-6">
                        <p>
                           <input type="text" placeholder="Your Name" />
                        </p>
                     </div>
                     <div class="col-lg-6">
                        <p>
                           <input type="text" placeholder="Email Address" />
                        </p>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-lg-6">
                        <p>
                           <input type="tel" placeholder="Phone Number" />
                        </p>
                     </div>
                     <div class="col-lg-6">
                        <p>
                           <input type="text" placeholder="Office Name" />
                        </p>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-lg-12">
                        <p>
                           <textarea placeholder="Send Testimonial"></textarea>
                        </p>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-lg-12">
                        <p>
                           <button type="submit">send message</button>
                        </p>
                     </div>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</section>
    

@include('includes.footerarea')
   </body>
</html>