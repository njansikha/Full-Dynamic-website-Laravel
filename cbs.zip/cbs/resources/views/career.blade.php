<!DOCTYPE html>
<html lang="en-US">
@include('includes.head')
   <body>
       
       
      <!-- Header Area Start -->
      <header class="finves-header-area">
         <!-- Header Top Area Start -->
         @include('includes.headertop')
         <!-- Header Top Area End -->
          
         <!-- Logo Area Start -->
         @include('includes.navarea')
         <!-- Logo Area End -->
      </header>
      <!-- Header Area End -->
       
       
      <!-- Breadcrumb Area Start -->
      <section class="finves-breadcromb-area">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="breadcromb-box">
                     <h3>Career</h3>
                     <ul>
                        <li><i class="fa fa-home"></i></li>
                        <li><a href="{{ url('/') }}">Home</a></li>
                        <li><i class="fa fa-angle-right"></i></li>
                        <li>Career</li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Breadcrumb Area End -->
       
       
      <!-- Blog Area Start -->
      <section class="finves-blog-page-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-4">
                  <div class="single-blog-item">
                     <div class="blog-image">
                        <a href="#">
                        <img src="assets/img/news-1.jpg" alt="news 1" />
                        </a>
                        <div class="blog-meta">
                           <p>Apply Now</p>
                        </div>
                     </div>
                     <div class="blog-text">
                        <a href="#">
                           <h3>Hiring For Field Sales Officers</h3>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="single-blog-item">
                     <div class="blog-image">
                        <a href="#">
                        <img src="assets/img/news-5.jpg" alt="news 1" />
                        </a>
                        <div class="blog-meta">
                           <p>Apply Now</p>
                        </div>
                     </div>
                     <div class="blog-text">
                        <a href="#">
                           <h3>Hiring For Excecutive Telecallers</h3>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="single-blog-item">
                     <div class="blog-image">
                        <a href="#">
                        <img src="assets/img/news-2.jpg" alt="news 1" />
                        </a>
                        <div class="blog-meta">
                           <p>Apply Now</p>
                        </div>
                     </div>
                     <div class="blog-text">
                        <a href="#">
                           <h3>Hiring For BRE</h3>
                        </a>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-4">
                  <div class="single-blog-item">
                     <div class="blog-image">
                        <a href="#">
                        <img src="assets/img/news-3.jpg" alt="news 1" />
                        </a>
                        <div class="blog-meta">
                           <p>Apply Now</p>
                        </div>
                     </div>
                     <div class="blog-text">
                        <a href="#">
                           <h3>Hiring For BRM</h3>
                        </a>
                     </div>
                  </div>
               </div>
             
            
            </div>
           
            <div class="row">
               <div class="col-lg-12">
                  <div class="pagination-box-row">
                     <p>Page 1 of 1</p>
                     <ul class="pagination">
                        <li class="active"><a href="#">1</a></li>
                        <!-- <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li>...</li>
                        <li><a href="#">6</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i></a></li> -->
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Blog Area End -->
       
       
      <!-- Footer Area Start -->
      @include('includes.footerarea')
   </body>
</html>

