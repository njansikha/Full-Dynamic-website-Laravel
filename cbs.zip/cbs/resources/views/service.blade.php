<!DOCTYPE html>
<html lang="en-US">
@include('includes.head')
   <body>
       
       
      <!-- Header Area Start -->
      <header class="finves-header-area">
         <!-- Header Top Area Start -->
         @include('includes.headertop')
         <!-- Header Top Area End -->
          
         <!-- Logo Area Start -->
         @include('includes.navarea')
         <!-- Logo Area End -->
      </header>
      <!-- Header Area End -->
       
       
      <!-- Breadcrumb Area Start -->
      <section class="finves-breadcromb-area">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="breadcromb-box">
                     <h3>Services</h3>
                     <ul>
                        <li><i class="fa fa-home"></i></li>
                        <li><a href="{{ url('/') }}">Home</a></li>
                        <li><i class="fa fa-angle-right"></i></li>
                        <li>All Services</li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Breadcrumb Area End -->
       
       
      <!-- Service Area Start -->
      <section class="service-page-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <div class="site-heading">
                     <h4>our Services</h4>
                     <h2>What We Do For You?</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-4">
                  <div class="single-service-box">
                     <div class="service-icon">
                        <img src="assets/img/service-icon-1.png" alt="service 1" />
                     </div>
                     <div class="service-text">
                        <a href="#">
                           <h3>Loans</h3>
                        </a>
                        <p>Personal Loans, Home Loans,Loan Aganist Property,Gold Loans, Vehicle Loans and other Loans are avaliable.</p>
                        <a href="loans.html" class="finves-btn">Read More <i class="fa fa-angle-double-right"></i></a>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="single-service-box">
                     <div class="service-icon">
                        <img src="assets/img/service-icon-6.png" alt="service 1" />
                     </div>
                     <div class="service-text">
                        <a href="Credit-Cards.html">
                           <h3>Credit Cards</h3>
                        </a>
                        <p>A credit card gives you access to 
                           funds for any purchase or expenses
                            based on your limit. </p>
                        <a href="Credit-Cards.html" class="finves-btn">Read More <i class="fa fa-angle-double-right"></i></a>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="single-service-box">
                     <div class="service-icon">
                        <img src="assets/img/service-icon-5.png" alt="service 1" />
                     </div>
                     <div class="service-text">
                        <a href="#">
                           <h3>Insurance & Annuities</h3>
                        </a>
                        <p>Health Insuarance, Life Insurance, Vechile Insurance etc  paid either on a 
                           monthly,  half-yearly, or yearly basis.
                           </p>
                        <a href="#" class="finves-btn">Read More <i class="fa fa-angle-double-right"></i></a>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-4">
                  <div class="single-service-box">
                     <div class="service-icon">
                        <img src="assets/img/service-icon-2.png" alt="service 1" />
                     </div>
                     <div class="service-text">
                        <a href="#">
                           <h3>Investment Management</h3>
                        </a>
                        <p>Outstanding long-term
                            investment performance, service and a comprehensive  investment  solutions.</p>
                        <a href="#" class="finves-btn">Read More <i class="fa fa-angle-double-right"></i></a>
                     </div>
                  </div>
               </div>
               <!-- <div class="col-lg-4">
                  <div class="single-service-box">
                     <div class="service-icon">
                        <img src="assets/img/service-icon-5.png" alt="service 1" />
                     </div>
                     <div class="service-text">
                        <a href="#">
                           <h3>Insurance & Annuities</h3>
                        </a>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry..</p>
                        <a href="#" class="finves-btn">Read More <i class="fa fa-angle-double-right"></i></a>
                     </div>
                  </div>
               </div> -->
               <div class="col-lg-4">
                  <div class="single-service-box">
                     <div class="service-icon">
                        <img src="assets/img/service-icon-4.png" alt="service 1" />
                     </div>
                     <div class="service-text">
                        <a href="#">
                           <h3>Wealth Management</h3>
                        </a>
                        <p>Advisory service that combines other
                            financial services to address the needs 
                            of affluent clients.</p>
                        <a href="#" class="finves-btn">Read More <i class="fa fa-angle-double-right"></i></a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Service Area End -->
       
       
      <!-- Promo Area Start -->
      <section class="finves-promo-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <div class="promo-box">
                     <p>We make a difference</p>
                     <h2>Implementing High <span>Financial Solutions</span></h2>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Promo Area End -->
       
       
      <!-- Client Area Start -->
      <!-- <section class="finves-client-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <div class="site-heading">
                     <h4>our Clients</h4>
                     <h2>Who work with us</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-12">
                  <div class="client-slider owl-carousel">
                     <a href="#">
                        <div  class="client-single">
                           <img src="assets/img/client-1.png" alt="client 1" />
                        </div>
                     </a>
                     <a href="#">
                        <div  class="client-single">
                           <img src="assets/img/client-2.png" alt="client 2" />
                        </div>
                     </a>
                     <a href="#">
                        <div  class="client-single">
                           <img src="assets/img/client-3.png" alt="client3" />
                        </div>
                     </a>
                     <a href="#">
                        <div  class="client-single">
                           <img src="assets/img/client-4.png" alt="client 4" />
                        </div>
                     </a>
                     <a href="#">
                        <div  class="client-single">
                           <img src="assets/img/client-2.png" alt="client 2" />
                        </div>
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </section> -->
      <!-- Client Area End -->
       
       
      <!-- Footer Area Start -->
      <footer class="finves-footer-area">
         <div class="footer-top-area">
            <div class="container">
               <div class="row">
                  <div class="col-lg-5 col-sm-6">
                     <div class="single-footer">
                        <h3>About Us</h3>
                        <p>Crest Banking Services to simplify your borrowing journey.</p>
                        <ul class="footer-about">
                           <li><i class="fa fa-map-marker"></i> <span>Address </span>: Trivandrum
                           </li>
                           <li><i class="fa fa-phone"></i> <span>Phone </span>: 096562 66777</li>
                           <li><i class="fa fa-envelope-o"></i> <span>Email </span>: info@crestbankingservices.com</li>
                           <li><a href="#"><i class="fa fa-facebook"></i></a> &nbsp;
                           <a href="#"><i class="fa fa-twitter"></i></a>&nbsp;
                           <a href="#"><i class="fa fa-vimeo"></i></a>&nbsp;
                           <a href="#"><i class="fa fa-pinterest"></i></a>&nbsp;
                           <a href="#"><i class="fa fa-skype"></i></a></li>
                       
                        </ul>
                        
                       
                        
                     </div>
                     
                      
                     
                  </div>
                  <div class="col-lg-3 col-sm-6">
                     <div class="single-footer">
                        <h3>Usefull Links</h3>
                        <ul class="usefull_links">
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Home</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>About Us</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Latest news</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Case Studies</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Meet Team</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Consultation</a></li>
                        </ul>
                        <ul class="usefull_links">
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Financial</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Private Banking</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Commodities</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Stock Holders</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Mutual Fund</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Stock Trading</a></li>
                        </ul>
                     </div>
                  </div>
                  <!-- <div class="col-lg-3 col-sm-6">
                     <div class="single-footer">
                        <h3>Subscribe Us</h3>
                        <p>Sign up for our mailing list to get latest updates and offers.</p>
                        <div class="footer-subscribe">
                           <form>
                              <input type="email" placeholder="Email Address" />
                              <button type="submit">GO</button>
                           </form>
                        </div>
                      
                     </div>
                  </div> -->
                  <div class="col-lg-3 col-sm-6">
                     <div class="single-footer">
                        <h3>Opening Hours</h3>
                        <ul class="footer-hours">
                           <li>Mon – Tue<span>10:00 – 18:00</span></li>
                           <li>Wed – Thur<span>10:00 – 17:00</span></li>
                           <li>Fri – Sat<span>10:00 – 12:30</span></li>
                           <li>Saturday<span>10:00 – 12:30</span></li>
                           <li>Sunday<span>Closed</span></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="copyright-area">
            <div class="container">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="copyright">
                        <p>Developed by  <a href="https://finklinzitservices.com/" target="_blank">FinkLinz IT Services</a> </p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- Footer Area End -->
       
       
      <!--Jquery js-->
      <script src="assets/js/jquery.min.js"></script>
      <!-- Popper JS -->
      <script src="assets/js/popper.min.js"></script>
      <!--Bootstrap js-->
      <script src="assets/js/bootstrap.min.js"></script>
      <!--Owl-Carousel js-->
      <script src="assets/js/owl.carousel.min.js"></script>
      <!--Slicknav js-->
      <script src="assets/js/jquery.slicknav.min.js"></script>
      <!--Isotop js-->
      <script src="assets/js/isotope.pkgd.min.js"></script>
      <script src="assets/js/custom-isotop.js"></script>
      <!--Magnific js-->
      <script src="assets/js/jquery.magnific-popup.min.js"></script>
      <!--Nice Select js-->
      <script src="assets/js/jquery.nice-select.min.js"></script>
      <!-- Counter JS -->
      <script src="assets/js/jquery.counterup.min.js"></script>
      <!-- Way Points JS -->
      <script src="assets/js/waypoints-min.js"></script>
      <!--Main js-->
      <script src="assets/js/main.js"></script>
   </body>
</html>

