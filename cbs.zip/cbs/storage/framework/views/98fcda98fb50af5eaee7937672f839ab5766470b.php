<!DOCTYPE html>
<html lang="en-US">
<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <body>
       
       
      <!-- Header Area Start -->
      <header class="finves-header-area">
         <!-- Header Top Area Start -->
         <?php echo $__env->make('includes.headertop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- Header Top Area End -->
          
         <!-- Logo Area Start -->
         <?php echo $__env->make('includes.navarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- Logo Area End -->
      </header>
      <!-- Header Area End -->
       
       
      <!-- Breadcrumb Area Start -->
      <section class="finves-breadcromb-area">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="breadcromb-box">
                     <h3>Contact Us</h3>
                     <ul>
                        <li><i class="fa fa-home"></i></li>
                        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li><i class="fa fa-angle-right"></i></li>
                        <li>Contact Us</li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Breadcrumb Area End -->
       
       
      <!-- Contact Area Start -->
      <section class="finves-contact-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-5">
                  <div class="contact-info">
                     <h3>Do You Have Any Question?</h3>
                     <p>Feel Free to contact us for any queries.</p>
                     <div class="contact-info inner-contact-info">
                        <div class="row">
                           <div class="col-md-12">
                              <div class="single-contact-info">
                                 <p>Feel like talking</p>
                                 <h6>+91 96562 66777</h6>
                              </div>
                           </div>
                           <div class="col-md-12">
                              <div class="single-contact-info">
                                 <p>Contact via email</p>
                                 <h6>info@crestbankingservices.com</h6>
                              </div>
                           </div>
                        </div>
                        <div class="row">
                          
                           <div class="col-md-12">
                              <div class="single-contact-info">
                                 <p>Head Office address</p>
                                 <h6>Crest Banking Services
                                    A16 (1)<br>
                                    Kanaka Nagar
                                    Vellayambalam 
                                    <br>Kowdiyar P.O
                                    695003</h6>
                              </div>
                           </div>

                            <div class="col-md-12">
                              <div class="single-contact-info">
                                 <p>get connected with</p>
                                 <ul class="contact-social">
                                    <li class="fb"><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li class="twt"><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li class="linkd"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li class="yt"><a href="#"><i class="fa fa-skype"></i></a></li>
                                 </ul>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-lg-7">
               <div class="col-sm-12">
                    <?php if(count($errors)>0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                        <center> <font color="red"><?php echo e($error); ?> </font>  </center>
              
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>

                  <div class="contact-form">
                     <form method="post" action="<?php echo e(url('/post-contact-message')); ?>" enctype="multipart/form-data"> 
                    <?php echo e(csrf_field()); ?>

                        <div class="row">
                           <div class="col-lg-6">
                              <p>
                                 <input type="text" placeholder="Your Name" name="name" required/>
                              </p>
                           </div>
                           <div class="col-lg-6">
                              <p>
                                 <input type="text" placeholder="Email Address" name="email"required/>
                              </p>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-lg-6">
                              <p>
                                 <input type="tel" placeholder="Phone Number" name="phone"required/>
                              </p>
                           </div>
                           <div class="col-lg-6">
                              <p>
                                 <input type="text" placeholder="Subject" name="subject" required/>
                              </p>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-lg-12">
                              <p>
                                 <textarea placeholder="Optional Message" name="message"required></textarea>
                              </p>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-lg-12">
                              <p>
                                 <button type="submit">send message</button>
                              </p>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Contact Area End -->
       
       
      <?php echo $__env->make('includes.footerarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </body>
</html>

<?php /**PATH C:\Vipinash\Laraval Project\cbs\resources\views/contact.blade.php ENDPATH**/ ?>