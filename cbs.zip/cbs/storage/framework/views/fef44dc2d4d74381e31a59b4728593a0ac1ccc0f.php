<!DOCTYPE html>
<html lang="en-US">
<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <style>
          table, th, td {
  border: 1px solid black;
  text-align:center;
  padding: auto;
}

      </style>
   <body>
       
       <?php $req_type="cc";
       ?>
      <!-- Header Area Start -->
      <header class="finves-header-area">
         <!-- Header Top Area Start -->
         <?php echo $__env->make('includes.headertop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- Header Top Area End -->
          
         <!-- Logo Area Start -->
         <?php echo $__env->make('includes.navarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- Logo Area End -->
      </header>
      <!-- Header Area End -->
       
       
      <!-- Breadcrumb Area Start -->
      <section class="finves-breadcromb-area">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="breadcromb-box">
                     <h3>Credit Cards</h3>
                     <ul>
                        <li><i class="fa fa-home"></i></li>
                        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li><i class="fa fa-angle-right"></i></li>
                        <li>Credit Cards</li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Breadcrumb Area End -->
       
       
      <!-- Service Details Area Start -->
      <section class="finves-service-details section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-4">
                  <div class="sidebar-left">
                  <?php echo $__env->make('includes.side_menu_services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  <!-- <?php echo $__env->make('includes.side_menu_address', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
                  <?php echo $__env->make('includes.side_menu_apply', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                     
                  </div>
               </div>
               <div class="col-lg-8">
                  <div class="service-details-right">

                  <div class="col-sm-12">
                    <?php if(count($errors)>0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                        <center> <font color="red"><?php echo e($error); ?> </font>  </center>
              
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                     <h2>Credit Cards</h2>
                     <p>

                        A credit card is a handy way to meet immediate expenses when you are low on cash flow. 
                        A credit card gives you access to funds for any purchase or expenses based on your limit. 
                        Following this, you get a month to make repayments towards the usedup limit.
                        Credit cards are also convenient for both online and offline transactions. You do not have to 
                        worry about carrying cash with you anymore. Not just that, you can enjoy several perks and 
                        benefits with every spend.
                        
                     </p>
                     <ul class="list-service-details">
                        <li>Rewards Credit Cards: </li>
                        <p> With these credit cards, the cardholder earns rewards points for 
                            every purchase or transaction.
                            </p>
                          <li>Corporate Credit Cards:</li> 
                        <p> Business or corporate credit cards are designed for companies, 
                            businesses, limited companies, banks, and partnerships that need an account to keep a track 
                            of its expenses..</p>
                        <li> Prepaid Credit Cards:</li>
                        <p> These credit cards are similar to debit cards having the benefits of a 
                            credit card. You can deposit a certain amount in an account which becomes your credit limit 
                            against which you can swipe the card. These Credit cards are ideal for individuals with low 
                            Credit score</p>
                            <li>  Travel Credit Cards:</li>
                            <p> These cards are usually offered by banks or other financial institutions 
                                in association with travel websites and airline companies. These cards offer special discounts 
                               
                                and privileges for bookings on these airlines and portals, such as air miles, access to airport 
                                lounges, rewards points, travel insurance, extra luggage, etc.</p>
                    
                     </ul>
                     <div class="service-right-image">
                        <div class="row">
                           <div class="col-lg-6 col-sm-6">
                              <div class="single-right-img">
                                 <img src="assets/img/service-9.jpg" alt="service 1" />
                              </div>
                           </div>
                           <div class="col-lg-6 col-sm-6">
                              <div class="single-right-img">
                                 <img src="assets/img/service-8.jpg" alt="service 2" />
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                     <div class="col-lg-12 col-sm-12">
                     <div class="service-inn">
                        <h3>Features and Benifits
                        </h3>
                        <p style="text-align: justify;">

                          <ul class="list-service-details">
                           <li>Credit Cards are the perfect alternative to cash. There is no need for carrying large amounts 
                            of money when you have a Credit Card.</li> 
                           <li> You get an interest-free window depending on the date of billing and the due date. The 
                            maximum interest-free period is between 45 and 55 days.</li> 
                           <li> Credit cardholders can avail cash advance facility on an urgent basis. Every Credit Card 
                            comes with a cash advance limit (not an interest-free advance). You have to pay interest on 
                            the cash advance portion from day 1.</li> 
                           <li>You can own a Credit Card and enjoy various benefits that come with it such as bonus points, 
                            gift vouchers, rewards programs, cashback benefits, and multiple other benefits.
                            </li> 
                           <li>Banks allow credit cardholders to apply for add-on cards for their family members. They can 
                            use these cards on an individual basis.
                            </li> 
                           <li> Banks issue unique Credit Cards that allow the cardholders to avail travel benefits like air 
                            miles, airport lounge access, airline offers, hotel offers, and travel insurance. These cards are 
                            also known as Co-branded Credit Cards.</li> 
                           <li> Some Credit Cards come with lifestyle benefits like dining, shopping, entertainment, and 
                            wellness and so forth.</li> 
                           <li>Repayment holiday facility</li> 
                           <li>Many banks offer fuel surcharge waivers to their credit cardholders.</li> 
                           <li>Proper usage of the Credit Card can improve your credit history</li> 
                       
                        </ul>   </p>
                     </div>
                    </div>

                    <!-- <div class="col-lg-6 col-sm-6">
                        <div class="service-inn">
                           <h3>Interest Rates & Charges
                           </h3>
                           <p>
                            With home loans, you have the option of both floating and fixed interest rates. Floating 
                            interest rates are linked to MCLR or Repo Rates depending upon the bank.
                            Here is a list of the Best Home Loan in India and the interest rates offered

                         </p>
                         <table >
                             <tr>
                                 <th>
                                     Bank
                                 </th>
                                 <th>
                                     Interest Rate
                                 </th>
                             </tr>
                             <tr>
                                 <td>State Bank of India</td>
                                 <td>6.70%
                                </td>
                             </tr>
                             <tr>
                                <td>State Bank of India</td>
                                <td>6.70%
                               </td>
                            </tr>
                            <tr>
                                <td>Kotak Mahindra bank</td>
                                <td>6.65%
                               </td>
                            </tr>
                            <tr>
                                <td>Citibank</td>
                                <td>6.75%

                               </td>
                            </tr>
                            
 
 
 
 
 
 
                            <tr>
                                <td>Union bank of India</td>
                                <td> 6.80%
                               </td>
                            </tr>

                            <tr>
                                <td>Bank of Baroda</td>
                                <td> 6.85%
                               </td>
                            </tr>
                            <tr>
                                <td>The Central bank of India</td>
                                <td> 6.85%
                               </td>
                            </tr>
                            <tr>
                                <td>Bank of India</td>
                                <td> 6.85%
                               </td>
                            </tr>
                            <tr>
                                <td>HDFC Ltd</td>
                                <td> 6.75%
                               </td>
                            </tr>
                            <tr>
                                <td>ICICI Bank</td>
                                <td> 6.90%
                               </td>
                            </tr>
                            <tr>
                                <td>LIC Housing Finance</td>
                                <td> 6.90%
                               </td>
                            </tr>
                         </table>
                    </div>
                   </div> -->


                    </div>

                     <!-- <div class="service_chart">
                        <h3>Strategy Develoment</h3>
                        <div id="morris_line_chart"></div>
                     </div> -->
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Service Details Area End -->
       
       
      <!-- Footer Area Start -->
      <footer class="finves-footer-area">
         <div class="footer-top-area">
            <div class="container">
               <div class="row">
                  <div class="col-lg-5 col-sm-6">
                     <div class="single-footer">
                        <h3>About Us</h3>
                        <p>Crest Banking Services to simplify your borrowing journey.</p>
                        <ul class="footer-about">
                           <li><i class="fa fa-map-marker"></i> <span>Address </span>: Trivandrum
                           </li>
                           <li><i class="fa fa-phone"></i> <span>Phone </span>: 096562 66777</li>
                           <li><i class="fa fa-envelope-o"></i> <span>Email </span>: info@crestbankingservices.com</li>
                           <li><a href="#"><i class="fa fa-facebook"></i></a> &nbsp;
                           <a href="#"><i class="fa fa-twitter"></i></a>&nbsp;
                           <a href="#"><i class="fa fa-vimeo"></i></a>&nbsp;
                           <a href="#"><i class="fa fa-pinterest"></i></a>&nbsp;
                           <a href="#"><i class="fa fa-skype"></i></a></li>
                       
                        </ul>
                        
                       
                        
                     </div>
                     
                      
                     
                  </div>
                  <div class="col-lg-3 col-sm-6">
                     <div class="single-footer">
                        <h3>Usefull Links</h3>
                        <ul class="usefull_links">
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Home</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>About Us</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Latest news</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Case Studies</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Meet Team</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Consultation</a></li>
                        </ul>
                        <ul class="usefull_links">
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Financial</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Private Banking</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Commodities</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Stock Holders</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Mutual Fund</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Stock Trading</a></li>
                        </ul>
                     </div>
                  </div>
                  <!-- <div class="col-lg-3 col-sm-6">
                     <div class="single-footer">
                        <h3>Subscribe Us</h3>
                        <p>Sign up for our mailing list to get latest updates and offers.</p>
                        <div class="footer-subscribe">
                           <form>
                              <input type="email" placeholder="Email Address" />
                              <button type="submit">GO</button>
                           </form>
                        </div>
                      
                     </div>
                  </div> -->
                  <div class="col-lg-3 col-sm-6">
                     <div class="single-footer">
                        <h3>Opening Hours</h3>
                        <ul class="footer-hours">
                           <li>Mon – Tue<span>10:00 – 18:00</span></li>
                           <li>Wed – Thur<span>10:00 – 17:00</span></li>
                           <li>Fri – Sat<span>10:00 – 12:30</span></li>
                           <li>Saturday<span>10:00 – 12:30</span></li>
                           <li>Sunday<span>Closed</span></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="copyright-area">
            <div class="container">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="copyright">
                        <p>Developed by  <a href="https://finklinzitservices.com/" target="_blank">FinkLinz IT Services</a> </p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- Footer Area End -->
       
       
      <!--Jquery js-->
      <script src="assets/js/jquery.min.js"></script>
      <!-- Popper JS -->
      <script src="assets/js/popper.min.js"></script>
      <!--Bootstrap js-->
      <script src="assets/js/bootstrap.min.js"></script>
      <!-- Raphael JS -->
      <script src="assets/js/raphael.min.js"></script>
      <!-- Morris JS -->
      <script src="assets/js/morris.min.js"></script>
      <!-- Custom Morris JS For Only Demo Purpose -->
      <script src="assets/js/custom_morris.js"></script>
      <!--Owl-Carousel js-->
      <script src="assets/js/owl.carousel.min.js"></script>
      <!--Slicknav js-->
      <script src="assets/js/jquery.slicknav.min.js"></script>
      <!--Isotop js-->
      <script src="assets/js/isotope.pkgd.min.js"></script>
      <script src="assets/js/custom-isotop.js"></script>
      <!--Magnific js-->
      <script src="assets/js/jquery.magnific-popup.min.js"></script>
      <!--Nice Select js-->
      <script src="assets/js/jquery.nice-select.min.js"></script>
      <!-- Counter JS -->
      <script src="assets/js/jquery.counterup.min.js"></script>
      <!-- Way Points JS -->
      <script src="assets/js/waypoints-min.js"></script>
      <!--Main js-->
      <script src="assets/js/main.js"></script>
   </body>
</html>

<?php /**PATH C:\Vipinash\Laraval Project\cbs\resources\views/credit_cards.blade.php ENDPATH**/ ?>