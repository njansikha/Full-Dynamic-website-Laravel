<!DOCTYPE html>
<html lang="en-US">
<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <style>
          table, th, td {
  border: 1px solid black;
  text-align:center;
  padding: auto;
}

      </style>
   <body>
   <?php $req_type="hl";
       ?>
       
      <!-- Header Area Start -->
      <header class="finves-header-area">
         <!-- Header Top Area Start -->
         <?php echo $__env->make('includes.headertop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- Header Top Area End -->
          
         <!-- Logo Area Start -->
         <?php echo $__env->make('includes.navarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- Logo Area End -->
      </header>
      <!-- Header Area End -->
       
       
      <!-- Breadcrumb Area Start -->
      <section class="finves-breadcromb-area">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="breadcromb-box">
                     <h3>Home Loans</h3>
                     <ul>
                        <li><i class="fa fa-home"></i></li>
                        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li><i class="fa fa-angle-right"></i></li>
                        <li>Loans</li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Breadcrumb Area End -->
       
       
      <!-- Service Details Area Start -->
      <section class="finves-service-details section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-4">
                  <div class="sidebar-left">
                  <?php echo $__env->make('includes.side_menu_services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                      <!-- <?php echo $__env->make('includes.side_menu_address', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
                  <?php echo $__env->make('includes.side_menu_apply', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  
                  
                  </div>
               </div>
               <div class="col-lg-8">

               <div class="col-sm-12">
                    <?php if(count($errors)>0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                        <center> <font color="red"><?php echo e($error); ?> </font>  </center>
              
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                  <div class="service-details-right">
                     <h2>Home Loans</h2>
                     <p>

                        Home loan is a secured bank loan for buying/ constructing a residential property. 
Currently, Kotak Home Loan is offering the most attractive housing loan interest rate 
starting at 6.50% p.a. Most Banks & HFCs sanction 75% to 90% of property value as home 
loans. Low processing fee, provisional sanction, 30 years of tenure & flexible EMIs are some 
of the many benefits of home loans.
                     </p>
                     <ul class="list-service-details">
                        <li>Lowest interest rate </li>
                        <p>Home loan interest rates are the lowest ever in the past 15 years. With raining festival offers 
                            on home loan, currently you can avail of the best interest rate on Kotak home loan @6.5% p.a 
                            for all loan amounts.</p>
                        <li>Affordable EMI Plans</li>
                        <p>You can avail the lowest Home Loan EMI at 746 per lakh with maximum repayment 
                            flexibility. Some options are Step-Up EMIs, Step Down EMIs, Moratorium, OD facility, 
                            balance transfer, top up and more.</p>
                        <li> No foreclosure Charge</li>
                        <p>Home Loans at floating interest rate (linked to repo rate) offer you ultimate prepayment 
                            flexibility. There is no part or full prepayment charge. You can prepay early & reduce interest 
                            cost as per your cash flows</p>
                    
                     </ul>
                     <div class="service-right-image">
                        <div class="row">
                           <div class="col-lg-6 col-sm-6">
                              <div class="single-right-img">
                                 <img src="assets/img/service-4.jpg" alt="service 1" />
                              </div>
                           </div>
                           <div class="col-lg-6 col-sm-6">
                              <div class="single-right-img">
                                 <img src="assets/img/service-3.jpg" alt="service 2" />
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                     <div class="col-lg-6 col-sm-6">
                     <div class="service-inn">
                        <h3>Features and Benifits
                        </h3>
                        <p style="text-align: justify;">

                          <ul class="list-service-details">
                           <li>Sense of accomplishment</li> 
                           <li>Tax benefits on interest and principal components</li> 
                           <li>Zero prepayment charges</li> 
                           <li>Home loan top up and balance transfer facility</li> 
                           <li>Long repayment tenure of up to 30 years</li> 
                           <li>High loan amount of up to 5 Crores (can be more in some cases)</li> 
                           <li>Makes it easy to purchase a new or resale house/apartment/plot, house construction, or even 
                            renovation of an existing house.</li> 
                           <li>Repayment holiday facility</li> 
                           <li>Loan available as term loan and overdraft</li> 
                           <li>Fixed, floating, and hybrid rates of interest available</li> 
                       
                        </ul>   </p>
                     </div>
                    </div>

                    <div class="col-lg-6 col-sm-6">
                        <div class="service-inn">
                           <h3>Interest Rates & Charges
                           </h3>
                           <p>
                            With home loans, you have the option of both floating and fixed interest rates. Floating 
                            interest rates are linked to MCLR or Repo Rates depending upon the bank.
                            Here is a list of the Best Home Loan in India and the interest rates offered

                         </p>
                         <table >
                             <tr>
                                 <th>
                                     Bank
                                 </th>
                                 <th>
                                     Interest Rate
                                 </th>
                             </tr>
                             <tr>
                                 <td>State Bank of India</td>
                                 <td>6.70%
                                </td>
                             </tr>
                             <tr>
                                <td>State Bank of India</td>
                                <td>6.70%
                               </td>
                            </tr>
                            <tr>
                                <td>Kotak Mahindra bank</td>
                                <td>6.65%
                               </td>
                            </tr>
                            <tr>
                                <td>Citibank</td>
                                <td>6.75%

                               </td>
                            </tr>
                            
 
 
 
 
 
 
                            <tr>
                                <td>Union bank of India</td>
                                <td> 6.80%
                               </td>
                            </tr>

                            <tr>
                                <td>Bank of Baroda</td>
                                <td> 6.85%
                               </td>
                            </tr>
                            <tr>
                                <td>The Central bank of India</td>
                                <td> 6.85%
                               </td>
                            </tr>
                            <tr>
                                <td>Bank of India</td>
                                <td> 6.85%
                               </td>
                            </tr>
                            <tr>
                                <td>HDFC Ltd</td>
                                <td> 6.75%
                               </td>
                            </tr>
                            <tr>
                                <td>ICICI Bank</td>
                                <td> 6.90%
                               </td>
                            </tr>
                            <tr>
                                <td>LIC Housing Finance</td>
                                <td> 6.90%
                               </td>
                            </tr>
                         </table>
                    </div>
                   </div>


                    </div>

                     <!-- <div class="service_chart">
                        <h3>Strategy Develoment</h3>
                        <div id="morris_line_chart"></div>
                     </div> -->
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Service Details Area End -->
       
       
      
      <?php echo $__env->make('includes.footerarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </body>
</html>

<?php /**PATH C:\Vipinash\Laraval Project\cbs\resources\views/home_loans.blade.php ENDPATH**/ ?>