<div class="single-sidebar">
                        <ul class="service-menu">
                           <li class="active"><a href="<?php echo e(url('/loans')); ?>">LOANS</a></li>
                           <li ><a href="<?php echo e(url('/home-loans')); ?>">Home Loans</a></li>
                           <li><a href="<?php echo e(url('/personal-loans')); ?>">Personal Loans</a></li>
                           <li><a href="<?php echo e(url('/gold-loans')); ?>">Gold Loans</a></li>
                           <li><a href="<?php echo e(url('/property-loans')); ?>">Loan Aganist Property</a></li>
                           <li><a href="<?php echo e(url('/loan-transfer')); ?>">Loan Balance Transfer</a></li>
                           <li class="active"><a href="<?php echo e(url('/credit-cards')); ?>">CREDIT CARDS</a></li>
                           <li class="active"><a href="<?php echo e(url('/wealth-management')); ?>">WEALTH MANAGEMENT </a></li>
                           <li class="active"><a href="<?php echo e(url('/investment-management')); ?>">INVETSMENT MANAGEMENT </a></li>
                        </ul>
                     </div><?php /**PATH C:\Vipinash\Laraval Project\cbs\resources\views/includes/side_menu_services.blade.php ENDPATH**/ ?>