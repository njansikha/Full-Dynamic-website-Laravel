<section class="finves-service-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <div class="site-heading">
                     <h4>our Services</h4>
                     <h2>What We Do For You?</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-12">
                  <div class="service-slider owl-carousel">
                     <div class="single-service-box">
                        <div class="service-icon">
                           <img src="assets/img/service-icon-1.png" alt="service 1" />
                        </div>
                        <div class="service-text">
                           <a href="#">
                              <h3>Loans</h3>
                           </a>
                           <p>Personal Loans, Home Loans,Loan Aganist Property,Gold Loans, Vehicle Loans and other Loans are avaliable.</p>
                           <a href="#" class="finves-btn">Read More <i class="fa fa-angle-double-right"></i></a>
                        </div>
                     </div>
                     <div class="single-service-box">
                        <div class="service-icon">
                           <img src="assets/img/service-icon-6.png" alt="service 1" />
                        </div>
                        <div class="service-text">
                           <a href="#">
                              <h3>Credit Cards</h3>
                           </a>
                           <p>A credit card gives you access to 
                              funds for any purchase or expenses
                               based on your limit. </p>
                           <a href="#" class="finves-btn">Read More <i class="fa fa-angle-double-right"></i></a>
                        </div>
                     </div>
                     <div class="single-service-box">
                        <div class="service-icon">
                           <img src="assets/img/service-icon-5.png" alt="service 1" />
                        </div>
                        <div class="service-text">
                           <a href="#">
                              <h3>Insurance & Annuities</h3>
                           </a>
                           <p>Health Insuarance, Life Insurance, Vechile Insurance etc  paid either on a 
                              monthly, quarterly, half-yearly, or yearly basis.
                              </p>
                           <a href="#" class="finves-btn">Read More <i class="fa fa-angle-double-right"></i></a>
                        </div>
                     </div>
                     <div class="single-service-box">
                        <div class="service-icon">
                           <img src="assets/img/service-icon-2.png" alt="service 1" />
                        </div>
                        <div class="service-text">
                           <a href="#">
                              <h3>Investment Management</h3>
                           </a>
                           <p>Outstanding long-term
                               investment performance, service and a comprehensive suite of investment management solutions.</p>
                           <a href="#" class="finves-btn">Read More <i class="fa fa-angle-double-right"></i></a>
                        </div>
                     </div>
                     <!-- <div class="single-service-box">
                        <div class="service-icon">
                           <img src="assets/img/service-icon-3.png" alt="service 1" />
                        </div>
                        <div class="service-text">
                           <a href="#">
                              <h3>Sales & trading</h3>
                           </a>
                           <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry..</p>
                           <a href="#" class="finves-btn">Read More <i class="fa fa-angle-double-right"></i></a>
                        </div>
                     </div> -->
                     <div class="single-service-box">
                        <div class="service-icon">
                           <img src="assets/img/service-icon-4.png" alt="service 1" />
                        </div>
                        <div class="service-text">
                           <a href="#">
                              <h3>Wealth Management</h3>
                           </a>
                           <p>Advisory service that combines other
                               financial services to address the needs 
                               of affluent clients.</p>
                           <a href="#" class="finves-btn">Read More <i class="fa fa-angle-double-right"></i></a>
                        </div>
                     </div>
                   
                     
                  </div>
               </div>
            </div>
         </div>
      </section><?php /**PATH C:\Vipinash\Laraval Project\cbs\resources\views/homepage/servicearea.blade.php ENDPATH**/ ?>