<section class="finves-investment-area section_70">
         <div class="container">
            <div class="row">
               <!-- <div class="col-lg-6">
                  <div class="investment-left">
                     <h2>EMI CALCULATOR</h2>
                     <form>
                        <div class="row">
                           <div class="col-lg-6">
                              <p>
                                 <label>Your Target ($)</label>
                                 <input type="text" placeholder="1000000" />
                              </p>
                           </div>
                           <div class="col-lg-6">
                              <p>
                                 <label>Duration (years)</label>
                                 <input type="text" placeholder="7 years" />
                              </p>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-lg-6">
                              <p>
                                 <label>Starting Principal ($)</label>
                                 <input type="text" placeholder="5000" />
                              </p>
                           </div>
                           <div class="col-lg-6">
                              <p>
                                 <label>Average Return (%)</label>
                                 <input type="text" placeholder="5" />
                              </p>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-lg-6">
                              <p>
                                 <label>Time Schedule</label>
                                 <select class="wide">
                                    <option>End of Each Month</option>
                                    <option>End of Each Year</option>
                                 </select>
                              </p>
                           </div>
                           <div class="col-lg-6">
                              <p>
                                 <button type="submit">Calculate</button>
                              </p>
                           </div>
                        </div>
                     </form>
                  </div>
               </div> -->
               <div class="col-lg-12">
                  <div class="investment-right">
                     <h2>Customers</h2>
                     <div id="morris_line_chart"></div>
                  </div>
               </div>
            </div>
         </div>
      </section><?php /**PATH C:\Vipinash\Laraval Project\cbs\resources\views/homepage/investmentarea.blade.php ENDPATH**/ ?>