<div class="finves-logo-area">
            <div class="container">
               <div class="row">
                  <div class="col-lg-3">
                     <div class="site-logo">
                        <a href="<?php echo e(url('/')); ?>">

                        
                           
                        <img src="assets/img/logo.png" alt="Site Logo" />
                        </a>
                     </div>
                     <!-- Responsive Menu Start -->
                     <div class="finves-responsive-menu"></div>
                     <!-- Responsive Menu End -->
                  </div>
                  <div class="col-lg-7">
                     <div class="mainmenu">
                        <nav>
                           <ul id="navigation_menu">
                              <li class="active"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                              <li><a href="<?php echo e(url('/about-us')); ?>">About us</a></li>
                              <li>
                                 <a href="<?php echo e(url('/services')); ?>">Services</a>
                                 <!-- <ul>
                                    <li><a href="service.html">All Services</a></li>
                                    <li><a href="single-service.html">Service Details</a></li>
                                 </ul> -->
                              </li>
                              <li>
                                 <a href="<?php echo e(url('/partners')); ?>">Partners</a>
                                 <!-- <ul>
                                    <li><a href="project-one.html">Project Style 1</a></li>
                                    <li><a href="project-two.html">Project Style 2</a></li>
                                    <li><a href="single-project.html">Project Details</a></li>
                                 </ul> -->
                              </li>
                              <li>
                                 <a href="<?php echo e(url('/testimonials')); ?>">Testimonials</a>
                                 <!-- <ul>
                                    <li><a href="404.html">404 error</a></li>
                                    <li><a href="team.html">Our Team</a></li>
                                    <li><a href="faq.html">FAQ's Page</a></li>
                                    <li><a href="login.html">Login</a></li>
                                    <li><a href="register.html">Register</a></li>
                                 </ul> -->
                              </li>
                              <li>
                                 <a href="<?php echo e(url('/careers')); ?>">Career</a>
                                 <!-- <ul>
                                    <li><a href="blog-grid.html">Blog Grid</a></li>
                                    <li><a href="blog-sidebar.html">Blog With Sidebar</a></li>
                                    <li><a href="single-blog.html">Blog details</a></li>
                                 </ul> -->
                              </li>
                              <li><a href="<?php echo e(url('/contact')); ?>">contact</a></li>
                           </ul>
                        </nav>
                     </div>
                  </div>

                  <?php

// ->value('logobig');
$phonenumber1 = DB::table('cbs_companyinfo')->where('id', '1')
    ->value('phonenumber');
// echo $logobig;

?>
                  <div class="col-lg-2">
                     <div class="header-action">
                        <a href="tel:+91 <?php echo e($phonenumber1); ?>">Call Us</a>
                     </div>
                  </div>
               </div>
            </div>
         </div><?php /**PATH C:\Vipinash\Laraval Project\cbs\resources\views/includes/navarea.blade.php ENDPATH**/ ?>