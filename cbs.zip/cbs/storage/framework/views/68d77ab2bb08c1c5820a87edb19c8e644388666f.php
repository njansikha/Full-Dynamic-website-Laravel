<section class="finves-slider-area">
         <div class="finves-slide owl-carousel">
            <div class="finves-main-slide slide-item-1">
               <div class="finves-main-caption">
                  <div class="finves-caption-cell">
                     <div class="container">
                        <div class="row">
                           <div class="col-md-12">
                              <div class="slider-text">
                                 <h2>Best Financial <span>Solutions</span></h2>
                                 <h3>for your Business</h3>
                                 <p>We provide quality financial advisory services to businesses located all over the World.</p>
                                 <a href="#" class="finves-btn">Contact us <i class="fa fa-angle-double-right"></i></a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="finves-main-slide slide-item-2">
               <div class="finves-main-caption">
                  <div class="finves-caption-cell">
                     <div class="container">
                        <div class="row">
                           <div class="col-md-12">
                              <div class="slider-text">
                                 <h2>Best Financial <span>Solutions</span></h2>
                                 <h3>for your Business</h3>
                                 <p>We provide quality financial advisory services to businesses located all over the World.</p>
                                 <a href="#" class="finves-btn">Contact us <i class="fa fa-angle-double-right"></i></a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="finves-main-slide slide-item-3">
               <div class="finves-main-caption">
                  <div class="finves-caption-cell">
                     <div class="container">
                        <div class="row">
                           <div class="col-md-12">
                              <div class="slider-text">
                                 <h2>Best Financial <span>Solutions</span></h2>
                                 <h3>for your Business</h3>
                                 <p>We provide quality financial advisory services to businesses located all over the World.</p>
                                 <a href="#" class="finves-btn">Contact us <i class="fa fa-angle-double-right"></i></a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="finves-main-slide slide-item-4">
               <div class="finves-main-caption">
                  <div class="finves-caption-cell">
                     <div class="container">
                        <div class="row">
                           <div class="col-md-12">
                              <div class="slider-text">
                                 <h2>Best Financial <span>Solutions</span></h2>
                                 <h3>for your Business</h3>
                                 <p>We provide quality financial advisory services to businesses located all over the World.</p>
                                 <a href="#" class="finves-btn">Contact us <i class="fa fa-angle-double-right"></i></a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="finves-main-slide slide-item-5">
               <div class="finves-main-caption">
                  <div class="finves-caption-cell">
                     <div class="container">
                        <div class="row">
                           <div class="col-md-12">
                              <div class="slider-text">
                                 <h2>Best Financial <span>Solutions</span></h2>
                                 <h3>for your Business</h3>
                                 <p>We provide quality financial advisory services to businesses located all over the World.</p>
                                 <a href="#" class="finves-btn">Contact us <i class="fa fa-angle-double-right"></i></a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section><?php /**PATH C:\Vipinash\Laraval Project\cbs\resources\views/homepage/sliderarea.blade.php ENDPATH**/ ?>