<!DOCTYPE html>
<html lang="en-US">
<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <body>
       
       
      <!-- Header Area Start -->
      <header class="finves-header-area">
         <!-- Header Top Area Start -->
         <?php echo $__env->make('includes.headertop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- Header Top Area End -->
          
         <!-- Logo Area Start -->
         <?php echo $__env->make('includes.navarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- Logo Area End -->
      </header>
      <!-- Header Area End -->
       
       
      <!-- Breadcrumb Area Start -->
      <section class="finves-breadcromb-area">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="breadcromb-box">
                     <h3>Our Partners</h3>
                     <ul>
                        <li><i class="fa fa-home"></i></li>
                        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li><i class="fa fa-angle-right"></i></li>
                        <li>Our Partners</li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Breadcrumb Area End -->
       
       
      <!-- Project Area Start -->
      <section class="finves-project-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <div class="site-heading">
                     <h4>our Partners</h4>
                     <h2>We Are Very Happy With Our Banking Partners</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-12">
                  <ul class="portfolio-filter">
                     <li class="filter active" data-filter="*">All Partners</li>
                     <li class="filter" data-filter=".loans">Loans</li>
                     <li class="filter" data-filter=".insurance">Insurance</li>
                     <li class="filter" data-filter=".cards">Credit Cards</li>
                     <!-- <li class="filter" data-filter=".marketing">Weal</li>
                     <li class="filter" data-filter=".strategy">strategy</li> -->
                  </ul>
               </div>
            </div>
            <div class="portfolio-warp">
               <div class="row isotope_items">
                  <!-- item -->
                  <div class="col-lg-4 col-md-6 insurance ">
                     <div class="work-item work-image">
                        <div class="project-img">
                           <img src="assets/img/work-1.jpg" alt="project">
                        </div>
                        <div class="content">
                           <h3>SBI LIFE</h3>
                           <p>SBI Life, a leading life insurance company in India, offers a range of life insurance plans
                               and policies to help you protect you and your family.</p>
                        </div>
                     </div>
                  </div>
                  <!-- item -->
                  <div class="col-lg-4 col-md-6 cards loans">
                     <div class="work-item">
                        <div class="project-img">
                           <img src="assets/img/work-2.jpg" alt="project">
                        </div>
                        <div class="content">
                           <h3>SBI</h3>
                           <p>State Bank of India, a financial powerhouse, provides banking services like saving account, 
                              fixed deposits, personal loans, education loan, SME loans, </p>
                        </div>
                     </div>
                  </div>
                  <!-- item -->
                  <div class="col-lg-4 col-md-6 cards">
                     <div class="work-item work-video">
                        <div class="project-img">
                           <img src="assets/img/work-3.jpg" alt="project">
                        </div>
                        <div class="content">
                           <h3>YES BANK</h3>
                           <p>YES BANK offers 
                              personal banking, corporate banking & internet banking services including accounts, deposits, 
                              credit cards, home loan, personal loans, ...</p>
                        </div>
                     </div>
                  </div>
                  <!-- item -->
                  <div class="col-lg-4 col-md-6 insurance">
                     <div class="work-item work-image">
                        <div class="project-img">
                           <img src="assets/img/work-5.jpg" alt="project">
                        </div>
                        <div class="content">
                           <h3>Bajaj Finserv</h3>
                           <p>Bajaj Finserv is India's most diversified NBFC. Get instant approval on loans and funds in account within 24 hours  </p>
                        </div>
                     </div>
                  </div>
                  <!-- item -->
                  <div class="col-lg-4 col-md-6 cards loans">
                     <div class="work-item">
                        <div class="project-img">
                           <img src="assets/img/work-4.jpg" alt="project">
                        </div>
                        <div class="content">
                           <h3>ICICI BANK</h3>
                           <p>ICICI Bank, a
                               leading private sector bank in India, offers Netbanking services & Personal banking services like Accounts & Deposits, Cards, Loans, ...</p>
                        </div>
                     </div>
                  </div>
                  <!-- item -->
                  <div class="col-lg-4 col-md-6 insurance">
                     <div class="work-item work-video">
                        <div class="project-img">
                           <img src="assets/img/work-6.jpg" alt="project">
                        </div>
                        <div class="content">
                           <h3>LIC INDIA</h3>
                           <p>LIC is a herd improvement and agri-technology co-operative that empowers farmers through the delivery of superior genetics and technology.</p>
                        </div>
                     </div>
                  </div>
                  <!-- item -->
               </div>
            </div>
         </div>
      </section>
      <!-- Project Area End -->
       
       
      <!-- Footer Area Start -->
      <footer class="finves-footer-area">
         <div class="footer-top-area">
            <div class="container">
               <div class="row">
                  <div class="col-lg-5 col-sm-6">
                     <div class="single-footer">
                        <h3>About Us</h3>
                        <p>Crest Banking Services to simplify your borrowing journey.</p>
                        <ul class="footer-about">
                           <li><i class="fa fa-map-marker"></i> <span>Address </span>: Trivandrum
                           </li>
                           <li><i class="fa fa-phone"></i> <span>Phone </span>: 096562 66777</li>
                           <li><i class="fa fa-envelope-o"></i> <span>Email </span>: info@crestbankingservices.com</li>
                           <li><a href="#"><i class="fa fa-facebook"></i></a> &nbsp;
                           <a href="#"><i class="fa fa-twitter"></i></a>&nbsp;
                           <a href="#"><i class="fa fa-vimeo"></i></a>&nbsp;
                           <a href="#"><i class="fa fa-pinterest"></i></a>&nbsp;
                           <a href="#"><i class="fa fa-skype"></i></a></li>
                       
                        </ul>
                        
                       
                        
                     </div>
                     
                      
                     
                  </div>
                  <div class="col-lg-3 col-sm-6">
                     <div class="single-footer">
                        <h3>Usefull Links</h3>
                        <ul class="usefull_links">
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Home</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>About Us</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Latest news</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Case Studies</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Meet Team</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Consultation</a></li>
                        </ul>
                        <ul class="usefull_links">
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Financial</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Private Banking</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Commodities</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Stock Holders</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Mutual Fund</a></li>
                           <li><a href="#"><i class="fa fa-angle-double-right"></i>Stock Trading</a></li>
                        </ul>
                     </div>
                  </div>
                  <!-- <div class="col-lg-3 col-sm-6">
                     <div class="single-footer">
                        <h3>Subscribe Us</h3>
                        <p>Sign up for our mailing list to get latest updates and offers.</p>
                        <div class="footer-subscribe">
                           <form>
                              <input type="email" placeholder="Email Address" />
                              <button type="submit">GO</button>
                           </form>
                        </div>
                      
                     </div>
                  </div> -->
                  <div class="col-lg-3 col-sm-6">
                     <div class="single-footer">
                        <h3>Opening Hours</h3>
                        <ul class="footer-hours">
                           <li>Mon – Tue<span>10:00 – 18:00</span></li>
                           <li>Wed – Thur<span>10:00 – 17:00</span></li>
                           <li>Fri – Sat<span>10:00 – 12:30</span></li>
                           <li>Saturday<span>10:00 – 12:30</span></li>
                           <li>Sunday<span>Closed</span></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="copyright-area">
            <div class="container">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="copyright">
                        <p>Developed by  <a href="https://finklinzitservices.com/" target="_blank">FinkLinz IT Services</a> </p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- Footer Area End -->
       
       
      <!--Jquery js-->
      <script src="assets/js/jquery.min.js"></script>
      <!-- Popper JS -->
      <script src="assets/js/popper.min.js"></script>
      <!--Bootstrap js-->
      <script src="assets/js/bootstrap.min.js"></script>
      <!--Owl-Carousel js-->
      <script src="assets/js/owl.carousel.min.js"></script>
      <!--Slicknav js-->
      <script src="assets/js/jquery.slicknav.min.js"></script>
      <!--Isotop js-->
      <script src="assets/js/isotope.pkgd.min.js"></script>
      <script src="assets/js/custom-isotop.js"></script>
      <!--Magnific js-->
      <script src="assets/js/jquery.magnific-popup.min.js"></script>
      <!--Nice Select js-->
      <script src="assets/js/jquery.nice-select.min.js"></script>
      <!-- Counter JS -->
      <script src="assets/js/jquery.counterup.min.js"></script>
      <!-- Way Points JS -->
      <script src="assets/js/waypoints-min.js"></script>
      <!--Main js-->
      <script src="assets/js/main.js"></script>
   </body>
</html>

<?php /**PATH C:\Vipinash\Laraval Project\cbs\resources\views/partners.blade.php ENDPATH**/ ?>