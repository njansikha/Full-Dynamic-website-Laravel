<!DOCTYPE html>
<html lang="en-US">
<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <style>
          table, th, td {
  border: 1px solid black;
  text-align:center;
  padding: auto;
}

      </style>
   <body>
   <?php $req_type="lt";
       ?>
       
       
       
      <!-- Header Area Start -->
      <header class="finves-header-area">
         <!-- Header Top Area Start -->
         <?php echo $__env->make('includes.headertop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- Header Top Area End -->
          
         <!-- Logo Area Start -->
         <?php echo $__env->make('includes.navarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- Logo Area End -->
      </header>
      <!-- Header Area End -->
       
       
      <!-- Breadcrumb Area Start -->
      <section class="finves-breadcromb-area">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="breadcromb-box">
                     <h3> Balance Transfer Loans</h3>
                     <ul>
                        <li><i class="fa fa-home"></i></li>
                        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li><i class="fa fa-angle-right"></i></li>
                        <li>Loans</li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Breadcrumb Area End -->
       
       
      <!-- Service Details Area Start -->
      <section class="finves-service-details section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-4">
                  <div class="sidebar-left">
                  <?php echo $__env->make('includes.side_menu_services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                      <!-- <?php echo $__env->make('includes.side_menu_address', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
                  <?php echo $__env->make('includes.side_menu_apply', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
               </div>
               <div class="col-lg-8">
               <div class="col-sm-12">
                    <?php if(count($errors)>0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                        <center> <font color="red"><?php echo e($error); ?> </font>  </center>
              
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                  <div class="service-details-right">
                     <h2> Loans Balance Transfer</h2>
                     <p>

                        Home Loan Balance Transfer (HLBT) is refinancing or switching of your existing Home Loan 
to a new lender. Using HLBT facility you can transfer Home Loan Balance to the new lender 
and avail of benefits such as lower Home Loan interest rate, affordable or readjusted EMIs, 
increase/decrease loan tenure and/or top up to 100% of Home Loan. Most lenders readily 
approve the balance transfer applications at lower rates because it is profitable and low risky 
to welcome customers already having a good repayment history. In the last one year maximum 
Home Loan Balance Transfer requests are made due to historic corrections in Home Loan 
Interest rates. The Home Loans (linked to repo rates) are available at lowest of 6.45% interest 
rate for 30 years. It is best to opt for Home Loan Transfer in the initial years, when your interest 
liability is high.
<br>
Let’s dig deep into the process of Home Loan Balance Transfer and understand how it works.

                     </p>
                     <ul class="list-service-details">
                        
                      
                       
                        
                        <li> The takeover of the outstanding Home Loan balance from the existing lender is treated as a 
                            fresh loan by the new lender.
                            
                            </li>
           
                        <li> Just like a new loan, the lender will assess stability of income, credit score, and KYC 
                            verification. A prescribed application for the balance transfer should be submitted to the 
                            existing lender.
                            </li>
  
                        <li> The panel advocate and the panel valuer of the new lender will undertake scrutiny of property 
                            documents and property valuation.</li>
                            <li>  The transfer of balance will be allowed by the existing lender only after the loan has run for a 
                                minimum period as prescribed at the time of loan approval. Until then, the No Objection 
                                Certificate (NOC) will not be issued by the lender.</li>     
                    
                     </ul>
                     <!-- <div class="service-right-image">
                        <div class="row">
                           <div class="col-lg-6 col-sm-6">
                              <div class="single-right-img">
                                 <img src="assets/img/service-4.jpg" alt="service 1" />
                              </div>
                           </div>
                           <div class="col-lg-6 col-sm-6">
                              <div class="single-right-img">
                                 <img src="assets/img/service-3.jpg" alt="service 2" />
                              </div>
                           </div>
                        </div>
                     </div> -->
                     <!-- <div class="row">
                     <div class="col-lg-6 col-sm-6">
                     <div class="service-inn">
                        <h3>Features and Benifits
                        </h3>
                        <p style="text-align: justify;">

                          <ul class="list-service-details">
                           <li>Sense of accomplishment</li> 
                           <li>Tax benefits on interest and principal components</li> 
                           <li>Zero prepayment charges</li> 
                           <li>Home loan top up and balance transfer facility</li> 
                           <li>Long repayment tenure of up to 30 years</li> 
                           <li>High loan amount of up to 5 Crores (can be more in some cases)</li> 
                           <li>Makes it easy to purchase a new or resale house/apartment/plot, house construction, or even 
                            renovation of an existing house.</li> 
                           <li>Repayment holiday facility</li> 
                           <li>Loan available as term loan and overdraft</li> 
                           <li>Fixed, floating, and hybrid rates of interest available</li> 
                       
                        </ul>   </p>
                     </div>
                    </div>

                    <div class="col-lg-6 col-sm-6">
                        <div class="service-inn">
                           <h3>Interest Rates & Charges
                           </h3>
                           <p>
                            With home loans, you have the option of both floating and fixed interest rates. Floating 
                            interest rates are linked to MCLR or Repo Rates depending upon the bank.
                            Here is a list of the Best Home Loan in India and the interest rates offered

                         </p>
                         <table >
                             <tr>
                                 <th>
                                     Bank
                                 </th>
                                 <th>
                                     Interest Rate
                                 </th>
                             </tr>
                             <tr>
                                 <td>State Bank of India</td>
                                 <td>6.70%
                                </td>
                             </tr>
                             <tr>
                                <td>State Bank of India</td>
                                <td>6.70%
                               </td>
                            </tr>
                            <tr>
                                <td>Kotak Mahindra bank</td>
                                <td>6.65%
                               </td>
                            </tr>
                            <tr>
                                <td>Citibank</td>
                                <td>6.75%

                               </td>
                            </tr>
                            
 
 
 
 
 
 
                            <tr>
                                <td>Union bank of India</td>
                                <td> 6.80%
                               </td>
                            </tr>

                            <tr>
                                <td>Bank of Baroda</td>
                                <td> 6.85%
                               </td>
                            </tr>
                            <tr>
                                <td>The Central bank of India</td>
                                <td> 6.85%
                               </td>
                            </tr>
                            <tr>
                                <td>Bank of India</td>
                                <td> 6.85%
                               </td>
                            </tr>
                            <tr>
                                <td>HDFC Ltd</td>
                                <td> 6.75%
                               </td>
                            </tr>
                            <tr>
                                <td>ICICI Bank</td>
                                <td> 6.90%
                               </td>
                            </tr>
                            <tr>
                                <td>LIC Housing Finance</td>
                                <td> 6.90%
                               </td>
                            </tr>
                         </table>
                    </div>
                   </div>


                    </div> -->

                     <!-- <div class="service_chart">
                        <h3>Strategy Develoment</h3>
                        <div id="morris_line_chart"></div>
                     </div> -->
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Service Details Area End -->
       
       
      <?php echo $__env->make('includes.footerarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </body>
</html>

<?php /**PATH C:\Vipinash\Laraval Project\cbs\resources\views/loan_transfer.blade.php ENDPATH**/ ?>