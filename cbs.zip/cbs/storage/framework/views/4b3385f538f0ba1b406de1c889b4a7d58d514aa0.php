<section class="finves-team-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <div class="site-heading">
                     <h4>our Experts</h4>
                     <h2>Meet Our Team</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-3 col-sm-6">
                  <div class="single-agent">
                     <div class="agent-image">
                        <img src="assets/img/team-image-1.jpg" alt="agent 2" />
                        <div class="hover">
                           <ul class="social-icon">
                              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                              <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                              <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                           </ul>
                        </div>
                     </div>
                     <div class="agent-text">
                        <h3><a href="#">Vipin C V</a></h3>
                        <p>Founder & C.E.O</p>
                     </div>
                  </div>
               </div>
               <!-- <div class="col-lg-3 col-sm-6">
                  <div class="single-agent">
                     <div class="agent-image">
                        <img src="assets/img/team-image-3.jpg" alt="agent 1" />
                        <div class="hover">
                           <ul class="social-icon">
                              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                              <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                              <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                           </ul>
                        </div>
                     </div>
                     <div class="agent-text">
                        <h3><a href="#">Arafa Sherief</a></h3>
                        <p>Business Expert</p>
                     </div>
                  </div>
               </div> -->
              
               <!-- <div class="col-lg-3 col-sm-6">
                  <div class="single-agent">
                     <div class="agent-image">
                        <img src="assets/img/team-image-4.jpg" alt="agent 3" />
                        <div class="hover">
                           <ul class="social-icon">
                              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                              <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                              <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                           </ul>
                        </div>
                     </div>
                     <div class="agent-text">
                        <h3><a href="#">Mody Magdy</a></h3>
                        <p>Senior HR Manager</p>
                     </div>
                  </div>
               </div> -->
               <!-- <div class="col-lg-3 col-sm-6">
                  <div class="single-agent">
                     <div class="agent-image">
                        <img src="assets/img/team-image-2.jpg" alt="agent 5" />
                        <div class="hover">
                           <ul class="social-icon">
                              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                              <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                              <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                           </ul>
                        </div>
                     </div>
                     <div class="agent-text">
                        <h3><a href="#">Sherief Arafa</a></h3>
                        <p>Marketing Expert</p>
                     </div>
                  </div>
               </div> -->
            </div>
         </div>
      </section><?php /**PATH C:\Vipinash\Laraval Project\cbs\resources\views/homepage/teamarea.blade.php ENDPATH**/ ?>