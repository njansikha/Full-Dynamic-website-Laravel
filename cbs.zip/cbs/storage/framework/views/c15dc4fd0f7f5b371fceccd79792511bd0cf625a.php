<!DOCTYPE html>
<html lang="en-US">
<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <body>
       
       
      <!-- Header Area Start -->
      <header class="finves-header-area">
         <!-- Header Top Area Start -->
         <?php echo $__env->make('includes.headertop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- Header Top Area End -->
          
         <!-- Logo Area Start -->
         <?php echo $__env->make('includes.navarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- Logo Area End -->
      </header>
      <!-- Header Area End -->
       
       
      <!-- Slider Area Start -->
      <?php echo $__env->make('homepage.sliderarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Slider Area End -->
       
       
      <!-- About Area Start -->
      <?php echo $__env->make('homepage.aboutarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- About Area End -->
       
       
      <!-- Service Area Start -->
      <?php echo $__env->make('homepage.servicearea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Service Area End -->
       
       
      <!-- Process Area Start -->
      <!-- <section class="finves-process-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <div class="site-heading">
                     <h2>Our Expert Financial Team Create Beautiful Solution</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-4">
                  <div class="single-process">
                     <div class="process-icon">
                        <i class="fa fa-google-wallet"></i>
                     </div>
                     <div class="process-text">
                        <h3>Get Deposit</h3>
                        <p>Lorem ipsum dolor sit amet consec tetur icing elit. Volup Atatibus fuga, laudan dolor ut iusto.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="single-process">
                     <div class="process-icon">
                        <i class="fa fa-university"></i>
                     </div>
                     <div class="process-text">
                        <h3>Utilize Money</h3>
                        <p>Lorem ipsum dolor sit amet consec tetur icing elit. Volup Atatibus fuga, laudan dolor ut iusto.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="single-process">
                     <div class="process-icon">
                        <i class="fa fa-thumbs-up"></i>
                     </div>
                     <div class="process-text">
                        <h3>Give Interest</h3>
                        <p>Lorem ipsum dolor sit amet consec tetur icing elit. Volup Atatibus fuga, laudan dolor ut iusto.</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section> -->
      <!-- Process Area End -->
       
       
      <!-- Investment Area Start -->
      <?php echo $__env->make('homepage.investmentarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Investment Area End -->
       
       
      <!-- Team Area Start -->
      <?php echo $__env->make('homepage.teamarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Team Area End -->
       
       
      <!-- Testimonial Area Start -->
      <?php echo $__env->make('homepage.testimonialarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Testimonial Area End -->
       
       
      <!-- Blog Area Start -->
      <!-- <section class="finves-blog-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <div class="site-heading">
                     <h4>news & Updates</h4>
                     <h2>Latest From Blog</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-4">
                  <div class="single-blog-item">
                     <div class="blog-image">
                        <a href="#">
                        <img src="assets/img/news-1.jpg" alt="news 1" />
                        </a>
                        <div class="blog-meta">
                           <p>15 DEC, 2019</p>
                        </div>
                     </div>
                     <div class="blog-text">
                        <a href="#">
                           <h3>Food industry leaders often change their promoters.</h3>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="single-blog-item">
                     <div class="blog-image">
                        <a href="#">
                        <img src="assets/img/news-3.jpg" alt="news 1" />
                        </a>
                        <div class="blog-meta">
                           <p>10 JAN, 2020</p>
                        </div>
                     </div>
                     <div class="blog-text">
                        <a href="#">
                           <h3>Strategy for Norway's Pesion Fund Global.</h3>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="single-blog-item">
                     <div class="blog-image">
                        <a href="#">
                        <img src="assets/img/news-2.jpg" alt="news 1" />
                        </a>
                        <div class="blog-meta">
                           <p>23 JAN, 2020</p>
                        </div>
                     </div>
                     <div class="blog-text">
                        <a href="#">
                           <h3>we are capable of the usually gets discovered.</h3>
                        </a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section> -->
      <!-- Blog Area End -->
       
       
      <!-- Footer Area Start -->
  
      <!-- Footer Area End -->
       
       
      <?php echo $__env->make('includes.footerarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </body>
</html>

<?php /**PATH C:\Vipinash\Laraval Project\cbs\resources\views/index.blade.php ENDPATH**/ ?>