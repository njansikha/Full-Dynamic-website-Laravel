<!DOCTYPE html>
<html lang="en-US">
<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <style>
          table, th, td {
  border: 1px solid black;
  text-align:center;
  padding: auto;
}

      </style>
   <body>
   <?php $req_type="pl";
       ?>
       
      <!-- Header Area Start -->
      <header class="finves-header-area">
         <!-- Header Top Area Start -->
         <?php echo $__env->make('includes.headertop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- Header Top Area End -->
          
         <!-- Logo Area Start -->
         <?php echo $__env->make('includes.navarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- Logo Area End -->
      </header>
      <!-- Header Area End -->
       
       
      <!-- Breadcrumb Area Start -->
      <section class="finves-breadcromb-area">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="breadcromb-box">
                     <h3>Personal Loans</h3>
                     <ul>
                        <li><i class="fa fa-home"></i></li>
                        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li><i class="fa fa-angle-right"></i></li>
                        <li>Loans</li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Breadcrumb Area End -->
       
       
      <!-- Service Details Area Start -->
      <section class="finves-service-details section_70">
         <div class="container">
            <div class="row">
               <div class="col-lg-4">
                  <div class="sidebar-left">
                  <?php echo $__env->make('includes.side_menu_services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                      <!-- <?php echo $__env->make('includes.side_menu_address', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
                  <?php echo $__env->make('includes.side_menu_apply', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
               </div>
               <div class="col-lg-8">

               <div class="col-sm-12">
                    <?php if(count($errors)>0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                        <center> <font color="red"><?php echo e($error); ?> </font>  </center>
              
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                  <div class="service-details-right">
                     <h2>Personal Loans</h2>
                     <p>

                        A personal loan is the best option to get access to funds in case of an emergency. Once you 
fulfill the necessary Personal Eligibility Criteria, you can meet any expense like medical 
emergency, travel needs, education fees, etc. with this simple, unsecured loan. 
                     </p>
                     <ul class="list-service-details">
                        <li> Current lowest personal loan interest rates start from 10.25% p.a.
                        </li>
                        <li> Compare 100+ personal loan banks at Crest Banking Services and choose the best one.
                        </li>
                        <li> Check fees & charges of all top banks offering personal loans in India.
                        </li>
                        <li> Get flexible tenure of 36 to 84 months to repay the loan.
                        </li>
                        <li> Submit online loan application and get instant loan approva
                        </li>
                        
                    
                     </ul>
                     <div class="service-right-image">
                        <div class="row">
                           <div class="col-lg-6 col-sm-6">
                              <div class="single-right-img">
                                 <img src="assets/img/service-7.jpg" alt="service 1" />
                              </div>
                           </div>
                           <div class="col-lg-6 col-sm-6">
                              <div class="single-right-img">
                                 <img src="assets/img/service-6.jpg" alt="service 2" />
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                     <div class="col-lg-6 col-sm-6">
                     <div class="service-inn">
                        <h3>Features and Benifits
                        </h3>
                        <p style="text-align: justify;">

                          <ul class="list-service-details">
                           <li>Sense of accomplishment</li> 
                           <li>Tax benefits on interest and principal components</li> 
                           <li>Zero prepayment charges</li> 
                           <li>Home loan top up and balance transfer facility</li> 
                           <li>Long repayment tenure of up to 30 years</li> 
                           <li>High loan amount of up to 5 Crores (can be more in some cases)</li> 
                           
                           <li>Repayment holiday facility</li> 
                           <li>Loan available as term loan and overdraft</li> 
                           <li>Fixed, floating, and hybrid rates of interest available</li> 
                       
                        </ul>   </p>
                     </div>
                    </div>

                    <div class="col-lg-6 col-sm-6">
                        <div class="service-inn">
                           <h3>Interest Rates & Charges
                           </h3>
                           <p>
                            With personal loans, you have the option of both floating and fixed interest rates. Floating 
                            interest rates are linked to MCLR or Repo Rates depending upon the bank.
                            Here is a list of the Best Home Loan in India and the interest rates offered

                         </p>
                         <table >
                             <tr>
                                 <th>
                                     Bank
                                 </th>
                                 <th>
                                     Interest Rate
                                 </th>
                             </tr>
                             <tr>
                                 <td>State Bank of India</td>
                                 <td>6.70%
                                </td>
                             </tr>
                             <tr>
                                <td>State Bank of India</td>
                                <td>6.70%
                               </td>
                            </tr>
                            <tr>
                                <td>Kotak Mahindra bank</td>
                                <td>6.65%
                               </td>
                            </tr>
                            <tr>
                                <td>Citibank</td>
                                <td>6.75%

                               </td>
                            </tr>
                            
 
 
 
 
 
 
                            <tr>
                                <td>Union bank of India</td>
                                <td> 6.80%
                               </td>
                            </tr>

                            <tr>
                                <td>Bank of Baroda</td>
                                <td> 6.85%
                               </td>
                            </tr>
                            <tr>
                                <td>The Central bank of India</td>
                                <td> 6.85%
                               </td>
                            </tr>
                            <tr>
                                <td>Bank of India</td>
                                <td> 6.85%
                               </td>
                            </tr>
                            <tr>
                                <td>HDFC Ltd</td>
                                <td> 6.75%
                               </td>
                            </tr>
                            <tr>
                                <td>ICICI Bank</td>
                                <td> 6.90%
                               </td>
                            </tr>
                           
                         </table>
                    </div>
                   </div>


                    </div>

                     <!-- <div class="service_chart">
                        <h3>Strategy Develoment</h3>
                        <div id="morris_line_chart"></div>
                     </div> -->
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Service Details Area End -->
       
       
       
      <?php echo $__env->make('includes.footerarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </body>
</html>

<?php /**PATH C:\Vipinash\Laraval Project\cbs\resources\views/personal_loans.blade.php ENDPATH**/ ?>